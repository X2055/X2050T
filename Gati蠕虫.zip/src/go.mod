module gati

go 1.21
