//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

// ---- DLL 句柄 ----------------------------------------------------------
var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
)

// ---- Win32 入口 --------------------------------------------------------
var (
	pRegisterClassExW = user32.NewProc("RegisterClassExW")
	pCreateWindowExW  = user32.NewProc("CreateWindowExW")
	pDefWindowProcW   = user32.NewProc("DefWindowProcW")
	pShowWindow       = user32.NewProc("ShowWindow")
	pShowWindowAsync  = user32.NewProc("ShowWindowAsync")
	pUpdateWindow     = user32.NewProc("UpdateWindow")
	pSetWindowPos     = user32.NewProc("SetWindowPos")
	pGetMessageW      = user32.NewProc("GetMessageW")
	pPeekMessageW     = user32.NewProc("PeekMessageW")
	pTranslateMessage = user32.NewProc("TranslateMessage")
	pDispatchMessageW = user32.NewProc("DispatchMessageW")
	pGetSystemMetrics = user32.NewProc("GetSystemMetrics")
	pPostQuitMessage  = user32.NewProc("PostQuitMessage")
	pDestroyWindow    = user32.NewProc("DestroyWindow")
	pSetTimer         = user32.NewProc("SetTimer")
	pKillTimer        = user32.NewProc("KillTimer")
	pInvalidateRect   = user32.NewProc("InvalidateRect")
	pBeginPaint       = user32.NewProc("BeginPaint")
	pEndPaint         = user32.NewProc("EndPaint")
	pFillRect         = user32.NewProc("FillRect")
	pGetClientRect    = user32.NewProc("GetClientRect")
	pDrawTextW        = user32.NewProc("DrawTextW")
	pSetWindowsHookEx = user32.NewProc("SetWindowsHookExW")
	pCallNextHookEx   = user32.NewProc("CallNextHookEx")
	pUnhookHookEx     = user32.NewProc("UnhookWindowsHookEx")
	pGetAsyncKeyState = user32.NewProc("GetAsyncKeyState")
	pFindWindowW      = user32.NewProc("FindWindowW")
	pMessageBoxW      = user32.NewProc("MessageBoxW")
	pGetCursorPos     = user32.NewProc("GetCursorPos")
	pSetCursorPos     = user32.NewProc("SetCursorPos")
	pClipCursor       = user32.NewProc("ClipCursor")
	pGetForegroundWin = user32.NewProc("GetForegroundWindow")
	pSetForegroundWin = user32.NewProc("SetForegroundWindow")
	pSystemParamInfo  = user32.NewProc("SystemParametersInfoW")

	pCreateSolidBrush = gdi32.NewProc("CreateSolidBrush")
	pCreateFontW      = gdi32.NewProc("CreateFontW")
	pSelectObject     = gdi32.NewProc("SelectObject")
	pDeleteObject     = gdi32.NewProc("DeleteObject")
	pSetTextColor     = gdi32.NewProc("SetTextColor")
	pSetBkMode        = gdi32.NewProc("SetBkMode")

	pGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")
	pGetLogicalDrives = kernel32.NewProc("GetLogicalDrives")
	pGetDriveTypeW    = kernel32.NewProc("GetDriveTypeW")
	pCreateMutexW     = kernel32.NewProc("CreateMutexW")
	pSleep            = kernel32.NewProc("Sleep")
	pGetTickCount64   = kernel32.NewProc("GetTickCount64")
)

// ---- 常量 --------------------------------------------------------------
const (
	WS_POPUP    = 0x80000000
	WS_VISIBLE  = 0x10000000
	WS_CHILD    = 0x40000000
	WS_EX_TOPMOST    = 0x00000008
	WS_EX_TOOLWINDOW = 0x00000080

	SW_HIDE = 0
	SW_SHOW = 5

	SWP_NOSIZE     = 0x0001
	SWP_NOMOVE     = 0x0002
	SWP_NOACTIVATE = 0x0010
	SWP_SHOWWINDOW = 0x0040

	WM_DESTROY         = 0x0002
	WM_CLOSE           = 0x0010
	WM_PAINT           = 0x000F
	WM_TIMER           = 0x0113
	WM_QUERYENDSESSION = 0x0011
	WM_ENDSESSION      = 0x0016
	WM_SYSCOMMAND      = 0x0112
	WM_ERASEBKGND      = 0x0014
	WM_NCHITTEST       = 0x0084
	WM_ACTIVATEAPP     = 0x001C
	WM_KEYDOWN         = 0x0100
	WM_SYSKEYDOWN      = 0x0104

	SC_CLOSE    = 0xF060
	SC_MINIMIZE = 0xF020
	SC_RESTORE  = 0xF120

	DT_LEFT      = 0x00000000
	DT_CENTER    = 0x00000001
	DT_RIGHT     = 0x00000002
	DT_VCENTER   = 0x00000004
	DT_WORDBREAK = 0x00000010
	DT_NOPREFIX  = 0x00000800
	DT_CALCRECT  = 0x00000400

	SM_XVIRTUALSCREEN  = 76
	SM_YVIRTUALSCREEN  = 77
	SM_CXVIRTUALSCREEN = 78
	SM_CYVIRTUALSCREEN = 79

	TRANSPARENT = 1

	WH_KEYBOARD_LL = 13
	HC_ACTION      = 0

	VK_LBUTTON  = 0x01
	VK_SHIFT    = 0x10
	VK_CONTROL  = 0x11
	VK_MENU     = 0x12
	VK_ESCAPE   = 0x1B
	VK_TAB      = 0x09
	VK_F4       = 0x73
	VK_F12      = 0x7B
	VK_LWIN     = 0x5B
	VK_RWIN     = 0x5C
	VK_APPS     = 0x5D
	VK_SNAPSHOT = 0x2C
	VK_DELETE   = 0x2E

	DRIVE_UNKNOWN     = 0
	DRIVE_NO_ROOT_DIR = 1
	DRIVE_REMOVABLE   = 2
	DRIVE_FIXED       = 3
	DRIVE_REMOTE      = 4
	DRIVE_CDROM       = 5
	DRIVE_RAMDISK     = 6
)

// HWND_TOPMOST = (HWND)-1
var hwndTopmost = ^uintptr(0)

// ---- 结构体 ------------------------------------------------------------
type rect struct {
	Left, Top, Right, Bottom int32
}

type point struct {
	X, Y int32
}

type msgStruct struct {
	Hwnd    syscall.Handle
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      point
}

type wndClassEx struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     syscall.Handle
	HIcon         syscall.Handle
	HCursor       syscall.Handle
	HbrBackground syscall.Handle
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       syscall.Handle
}

type paintStruct struct {
	Hdc         syscall.Handle
	FErase      int32
	RcPaint     rect
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}

type kbdllHookStruct struct {
	VkCode      uint32
	ScanCode    uint32
	Flags       uint32
	Time        uint32
	DwExtraInfo uintptr
}

// colorref 把 0xRRGGBB 转成 Windows 的 COLORREF(0x00BBGGRR)
func colorref(rgbHex uint32) uint32 {
	r := (rgbHex >> 16) & 0xFF
	g := (rgbHex >> 8) & 0xFF
	b := rgbHex & 0xFF
	return r | g<<8 | b<<16
}

func keyDown(vk int) bool {
	r, _, _ := pGetAsyncKeyState.Call(uintptr(vk))
	return r&0x8000 != 0
}

func unsafePointer(p *uint16) uintptr {
	return uintptr(unsafe.Pointer(p))
}

func unsafePtr(p *uint16) uintptr {
	return uintptr(unsafe.Pointer(p))
}
