//go:build windows

package main

import (
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var (
	textMu    sync.RWMutex
	curText   string
	dispFg    uint32
	dispBg    uint32
	blinkOn   = true
	scrollTop int32
	fontH     int32
)

func textPath() string {
	p := gCfg.TextFile
	if !filepath.IsAbs(p) {
		dir := baseDir
		if activeIni != "" {
			dir = filepath.Dir(activeIni)
		}
		p = filepath.Join(dir, p)
	}
	return p
}

func reloadText() {
	p := textPath()
	b, err := os.ReadFile(p)
	if err != nil {
		return
	}
	s := string(b)
	// 去掉 BOM
	if len(s) >= 3 && s[0] == 0xEF && s[1] == 0xBB && s[2] == 0xBF {
		s = s[3:]
	}
	textMu.Lock()
	curText = s
	textMu.Unlock()
}

func getText() string {
	textMu.RLock()
	defer textMu.RUnlock()
	return curText
}

// ---- 窗口过程 ----------------------------------------------------------
func wndProc(hwnd uintptr, msg uintptr, wParam uintptr, lParam uintptr) uintptr {
	switch msg {
	case WM_PAINT:
		paintWindow(hwnd)
		return 0

	case WM_ERASEBKGND:
		return 1

	case WM_CLOSE:
		// 拒绝关闭 —— 直接吞掉
		return 0

	case WM_SYSCOMMAND:
		cmd := wParam & 0xFFF0
		if cmd == SC_CLOSE || cmd == SC_MINIMIZE {
			return 0
		}

	case WM_QUERYENDSESSION:
		return 0

	case WM_TIMER:
		if stopFileExists() {
			pPostQuitMessage.Call(0)
			return 0
		}
		// 每秒重新压一次 topmost,防止被别的窗口盖住
		pSetWindowPos.Call(hwnd, hwndTopmost, 0, 0, 0, 0,
			SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW)
		pInvalidateRect.Call(hwnd, 0, 0)
		return 0

	case WM_ACTIVATEAPP:
		return 0
	}

	ret, _, _ := pDefWindowProcW.Call(hwnd, msg, wParam, lParam)
	return ret
}

var wndProcCb = syscall.NewCallback(wndProc)

func alignFlags() uintptr {
	switch gCfg.Align {
	case "left":
		return DT_LEFT | DT_WORDBREAK | DT_NOPREFIX
	case "right":
		return DT_RIGHT | DT_WORDBREAK | DT_NOPREFIX
	}
	return DT_CENTER | DT_WORDBREAK | DT_NOPREFIX
}

func makeFont(size int) uintptr {
	face, _ := syscall.UTF16PtrFromString(gCfg.FontName)
	font, _, _ := pCreateFontW.Call(
		uintptr(int32(-size)), // 负值 = 按字符高度而不是单元格高度
		0, 0, 0,
		700, // FW_BOLD
		0, 0, 0,
		1, // DEFAULT_CHARSET
		0, 0, 0, 0,
		uintptr(unsafe.Pointer(face)),
	)
	return font
}

// measureText 用当前选中的字体量出文字块高度
func measureText(hdc uintptr, txtPtr uintptr, rc rect, flags uintptr) int32 {
	measure := rc
	measure.Left += 40
	measure.Right -= 40
	measure.Top = 0
	measure.Bottom = 200000
	pDrawTextW.Call(hdc, txtPtr, ^uintptr(0),
		uintptr(unsafe.Pointer(&measure)), flags|DT_CALCRECT)
	return measure.Bottom - measure.Top
}

func paintWindow(hwnd uintptr) {
	var rc rect
	pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))

	var ps paintStruct
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	defer pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	// 背景
	brush, _, _ := pCreateSolidBrush.Call(uintptr(dispBg))
	if brush != 0 {
		pFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), brush)
		pDeleteObject.Call(brush)
	}

	txt := getText()
	if txt == "" {
		return
	}

	fg := dispFg
	if gCfg.Blink && !blinkOn {
		fg = dispBg
	}

	txtPtr, _ := syscall.UTF16PtrFromString(txt)
	flags := alignFlags()

	// 自动缩字号:文字放不下就一级一级缩,最小 14 号
	size := gCfg.FontSize
	var font uintptr
	var oldFont uintptr
	var textH int32
	avail := rc.Bottom - rc.Top - 20

	for {
		font = makeFont(size)
		if font == 0 {
			return
		}
		oldFont, _, _ = pSelectObject.Call(hdc, font)
		textH = measureText(hdc, uintptr(unsafe.Pointer(txtPtr)), rc, flags)
		if textH <= avail || size <= 14 || gCfg.Mode == "scroll" {
			break
		}
		pSelectObject.Call(hdc, oldFont)
		pDeleteObject.Call(font)
		size = int(float64(size) * 0.85)
		if size < 14 {
			size = 14
		}
	}

	pSetTextColor.Call(hdc, uintptr(fg))
	pSetBkMode.Call(hdc, TRANSPARENT)

	if gCfg.Mode == "scroll" {
		// 从下往上滚动
		if scrollTop == 0 {
			scrollTop = rc.Bottom
		}
		draw := rc
		draw.Left += 40
		draw.Right -= 40
		draw.Top = scrollTop
		draw.Bottom = scrollTop + textH + 40
		pDrawTextW.Call(hdc, uintptr(unsafe.Pointer(txtPtr)), ^uintptr(0),
			uintptr(unsafe.Pointer(&draw)), flags)

		scrollTop -= int32(gCfg.ScrollSpeed) * 4
		if scrollTop+textH < 0 {
			scrollTop = rc.Bottom
		}
	} else {
		// 垂直居中
		fontH = textH
		draw := rc
		draw.Left += 40
		draw.Right -= 40
		top := (rc.Bottom - rc.Top - textH) / 2
		if top < 0 {
			top = 0
		}
		draw.Top = top
		draw.Bottom = top + textH + 20
		pDrawTextW.Call(hdc, uintptr(unsafe.Pointer(txtPtr)), ^uintptr(0),
			uintptr(unsafe.Pointer(&draw)), flags)
	}

	pSelectObject.Call(hdc, oldFont)
	pDeleteObject.Call(font)
}

// displayLoop 建窗口 + 跑消息循环,必须跑在锁定线程上
func displayLoop() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	dispFg = colorref(hexColor(gCfg.FgColor, 0xFF2D2D))
	dispBg = colorref(hexColor(gCfg.BgColor, 0x000000))
	reloadText()

	hInst, _, _ := pGetModuleHandleW.Call(0)
	clsName, _ := syscall.UTF16PtrFromString("GatiOverlayWnd")
	winTitle, _ := syscall.UTF16PtrFromString("Gati")

	wc := wndClassEx{
		LpfnWndProc:   wndProcCb,
		HInstance:     syscall.Handle(hInst),
		LpszClassName: clsName,
	}
	wc.CbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	vx, _, _ := pGetSystemMetrics.Call(SM_XVIRTUALSCREEN)
	vy, _, _ := pGetSystemMetrics.Call(SM_YVIRTUALSCREEN)
	vw, _, _ := pGetSystemMetrics.Call(SM_CXVIRTUALSCREEN)
	vh, _, _ := pGetSystemMetrics.Call(SM_CYVIRTUALSCREEN)
	if vw == 0 || vh == 0 {
		vw, vh = 1920, 1080
	}

	n := gCfg.WindowCount
	if n < 1 {
		n = 1
	}
	segW := int(vw) / n

	handles := make([]uintptr, 0, n)
	for i := 0; i < n; i++ {
		x := int(vx) + i*segW
		w := segW
		if i == n-1 {
			w = int(vw) - i*segW
		}
		h, _, _ := pCreateWindowExW.Call(
			WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
			uintptr(unsafe.Pointer(clsName)),
			uintptr(unsafe.Pointer(winTitle)),
			WS_POPUP|WS_VISIBLE,
			uintptr(x), uintptr(vy), uintptr(w), uintptr(vh),
			0, 0, hInst, 0,
		)
		if h != 0 {
			handles = append(handles, h)
			pSetWindowPos.Call(h, hwndTopmost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE)
			pShowWindow.Call(h, SW_SHOW)
			pSetTimer.Call(h, uintptr(i+1), 100, 0)
		}
	}

	if gCfg.HideTaskbar {
		hideTaskbar(true)
	}

	// 后台刷新:文字重载 / 闪烁 / 文件监控
	go func() {
		lastReload := time.Now()
		for {
			if stopFileExists() {
				return
			}
			if time.Since(lastReload) >= time.Duration(gCfg.ReloadMs)*time.Millisecond {
				reloadText()
				lastReload = time.Now()
			}
			if gCfg.Blink {
				blinkOn = !blinkOn
				for _, h := range handles {
					pInvalidateRect.Call(h, 0, 0)
				}
				time.Sleep(time.Duration(gCfg.BlinkMs) * time.Millisecond)
				continue
			}
			time.Sleep(300 * time.Millisecond)
		}
	}()

	var m msgStruct
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}

	for _, h := range handles {
		pDestroyWindow.Call(h)
	}
	logf("display loop exited")
}

func hideTaskbar(hide bool) {
	cls, _ := syscall.UTF16PtrFromString("Shell_TrayWnd")
	h, _, _ := pFindWindowW.Call(uintptr(unsafe.Pointer(cls)), 0)
	if h == 0 {
		return
	}
	if hide {
		pShowWindowAsync.Call(h, SW_HIDE)
	} else {
		pShowWindowAsync.Call(h, SW_SHOW)
	}
}
