#!/usr/bin/env bash
# Gati 构建脚本 —— 交叉编译出 Windows 可执行文件
set -e
cd "$(dirname "$0")"

mkdir -p dist

echo "[1/3] 编译 GUI 版 Gati.exe"
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 \
  go build -trimpath -ldflags "-s -w -H=windowsgui" -o dist/Gati.exe .

echo "[2/3] 编译调试版 Gati_console.exe"
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 \
  go build -trimpath -ldflags "-s -w" -o dist/Gati_console.exe .

echo "[3/3] 复制配置和文案"
cp gati.ini dist/gati.ini
cp gati_text.txt dist/gati_text.txt

ls -la dist/
echo "BUILD_OK"
