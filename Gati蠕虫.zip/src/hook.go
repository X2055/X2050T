//go:build windows

package main

import (
	"runtime"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var unlockOnce sync.Once

func hookProc(nCode int32, wParam uintptr, kb *kbdllHookStruct) uintptr {
	if nCode == HC_ACTION && kb != nil {

		// 先看是不是紧急解锁组合键
		if matchesUnlock(int(kb.VkCode)) {
			unlockOnce.Do(func() {
				go func() {
					time.Sleep(80 * time.Millisecond)
					logf("unlock hotkey pressed")
					doUnlock()
				}()
			})
			return 1
		}

		if gCfg != nil && gCfg.BlockHotkeys && shouldBlock(int(kb.VkCode)) {
			return 1
		}
	}
	ret, _, _ := pCallNextHookEx.Call(0, uintptr(nCode), wParam, uintptr(unsafe.Pointer(kb)))
	return ret
}

var hookProcCb = syscall.NewCallback(hookProc)

func matchesUnlock(vk int) bool {
	if gCfg == nil || vk != gCfg.UnlockVK {
		return false
	}
	if gCfg.UnlockCtrl != keyDown(VK_CONTROL) {
		return false
	}
	if gCfg.UnlockAlt != keyDown(VK_MENU) {
		return false
	}
	if gCfg.UnlockShift != keyDown(VK_SHIFT) {
		return false
	}
	return true
}

func shouldBlock(vk int) bool {
	ctrl := keyDown(VK_CONTROL)
	alt := keyDown(VK_MENU)
	shift := keyDown(VK_SHIFT)

	switch vk {
	case VK_LWIN, VK_RWIN, VK_APPS:
		return true
	case VK_F4:
		return alt
	case VK_TAB:
		return alt
	case VK_ESCAPE:
		return ctrl || alt
	case VK_F12:
		return ctrl && shift
	case VK_DELETE:
		// Ctrl+Alt+Del 拦不住(系统级),但 Ctrl+Shift+Del 可以
		return ctrl && shift
	}
	return false
}

// hotkeyLoop 装全局低级键盘钩子
func hotkeyLoop() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	if gCfg == nil || !gCfg.BlockHotkeys {
		return
	}

	hInst, _, _ := pGetModuleHandleW.Call(0)
	hk, _, err := pSetWindowsHookEx.Call(WH_KEYBOARD_LL, hookProcCb, hInst, 0)
	if hk == 0 {
		logf("keyboard hook failed: %v", err)
		return
	}
	logf("keyboard hook installed")

	var m msgStruct
	for {
		if stopFileExists() {
			break
		}
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	pUnhookHookEx.Call(hk)
}
