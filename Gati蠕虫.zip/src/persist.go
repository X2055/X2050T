//go:build windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const runKey = `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`
const polKey = `HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System`

// ---- 小工具 ------------------------------------------------------------
func hiddenCmd(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return cmd.Run()
}

func spawnDetached(path string) error {
	cmd := exec.Command(path)
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: 0x00000008, // DETACHED_PROCESS
	}
	return cmd.Start()
}

func stopFile() string {
	return filepath.Join(baseDir, "STOP.sgn")
}

func stopFileExists() bool {
	_, err := os.Stat(stopFile())
	return err == nil
}

func hbPath(role string) string {
	return filepath.Join(baseDir, "hb_"+role+".ts")
}

func writeHeartbeat(role string) {
	_ = os.WriteFile(hbPath(role), []byte(strconv.FormatInt(time.Now().UnixNano(), 10)), 0644)
}

func heartbeatAge(role string) time.Duration {
	b, err := os.ReadFile(hbPath(role))
	if err != nil {
		return time.Hour
	}
	n, err := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
	if err != nil {
		return time.Hour
	}
	return time.Since(time.Unix(0, n))
}

// ---- 安装:把自己和配置文件复制到 %APPDATA%\Gati ------------------------
func installSelf() {
	_ = os.MkdirAll(baseDir, 0755)

	for _, name := range []string{"gati.ini", "gati_text.txt"} {
		src := filepath.Join(filepath.Dir(selfPath), name)
		dst := filepath.Join(baseDir, name)
		if _, err := os.Stat(dst); err == nil {
			continue
		}
		if b, err := os.ReadFile(src); err == nil {
			_ = os.WriteFile(dst, b, 0644)
		}
	}

	target := filepath.Join(baseDir, "gati-"+myRole+".exe")
	if !samePath(selfPath, target) {
		if b, err := os.ReadFile(selfPath); err == nil {
			_ = os.WriteFile(target, b, 0755)
		}
	}

	// 另一份
	other := "b"
	if myRole == "b" {
		other = "a"
	}
	otherExe := filepath.Join(baseDir, "gati-"+other+".exe")
	if _, err := os.Stat(otherExe); err != nil {
		if b, err := os.ReadFile(target); err == nil {
			_ = os.WriteFile(otherExe, b, 0755)
		}
	}
}

func samePath(a, b string) bool {
	aa, _ := filepath.Abs(a)
	bb, _ := filepath.Abs(b)
	return strings.EqualFold(aa, bb)
}

// ---- 持久化 ------------------------------------------------------------
func installPersistence() {
	if !gCfg.PersistEnabled {
		return
	}
	exeA := filepath.Join(baseDir, "gati-a.exe")

	// 1. 注册表 Run
	_ = hiddenCmd("reg", "add", runKey, "/v", "GatiHost", "/t", "REG_SZ",
		"/d", `"`+exeA+`"`, "/f")
	_ = hiddenCmd("reg", "add", runKey, "/v", "GatiHostB", "/t", "REG_SZ",
		"/d", `"`+filepath.Join(baseDir, "gati-b.exe")+`"`, "/f")

	// 2. 启动文件夹
	if gCfg.StartupFolder {
		startup := filepath.Join(os.Getenv("APPDATA"),
			`Microsoft\Windows\Start Menu\Programs\Startup`)
		if _, err := os.Stat(startup); err == nil {
			if b, err := os.ReadFile(exeA); err == nil {
				_ = os.WriteFile(filepath.Join(startup, "GatiHost.exe"), b, 0755)
			}
		}
	}

	// 3. 计划任务(登录触发)
	if gCfg.ScheduledTask {
		_ = hiddenCmd("schtasks", "/create", "/tn", "GatiHost",
			"/tr", `"`+exeA+`"`, "/sc", "onlogon", "/rl", "highest", "/f")
	}

	logf("persistence installed")
}

func removePersistence() {
	_ = hiddenCmd("reg", "delete", runKey, "/v", "GatiHost", "/f")
	_ = hiddenCmd("reg", "delete", runKey, "/v", "GatiHostB", "/f")
	_ = hiddenCmd("schtasks", "/delete", "/tn", "GatiHost", "/f")
	startup := filepath.Join(os.Getenv("APPDATA"),
		`Microsoft\Windows\Start Menu\Programs\Startup`)
	_ = os.Remove(filepath.Join(startup, "GatiHost.exe"))
}

// ---- 锁定项 ------------------------------------------------------------
func applyLockdown() {
	if gCfg.BlockTaskmgr {
		_ = hiddenCmd("reg", "add", polKey, "/v", "DisableTaskMgr", "/t", "REG_DWORD", "/d", "1", "/f")
		_ = hiddenCmd("reg", "add", polKey, "/v", "DisableRegistryTools", "/t", "REG_DWORD", "/d", "1", "/f")
	}
	if gCfg.HideTaskbar {
		hideTaskbar(true)
	}
}

func releaseLockdown() {
	_ = hiddenCmd("reg", "add", polKey, "/v", "DisableTaskMgr", "/t", "REG_DWORD", "/d", "0", "/f")
	_ = hiddenCmd("reg", "add", polKey, "/v", "DisableRegistryTools", "/t", "REG_DWORD", "/d", "0", "/f")
	hideTaskbar(false)
}

// ---- 看门狗 ------------------------------------------------------------
func watchdogLoop() {
	if !gCfg.Watchdog {
		writeHeartbeat(myRole)
		for !stopFileExists() {
			time.Sleep(2 * time.Second)
			writeHeartbeat(myRole)
		}
		return
	}

	other := "b"
	if myRole == "b" {
		other = "a"
	}
	otherExe := filepath.Join(baseDir, "gati-"+other+".exe")

	// 第一次启动时把同伴拉起来
	if heartbeatAge(other) > 8*time.Second {
		if _, err := os.Stat(otherExe); err == nil {
			_ = spawnDetached(otherExe)
			logf("spawned peer %s", other)
		}
	}

	for {
		if stopFileExists() {
			logf("stop flag found, watchdog exits")
			return
		}
		writeHeartbeat(myRole)
		if heartbeatAge(other) > 8*time.Second {
			if _, err := os.Stat(otherExe); err == nil {
				logf("peer %s missing, respawn", other)
				_ = spawnDetached(otherExe)
			}
		}
		time.Sleep(2 * time.Second)
	}
}

// ---- 解锁:清理一切痕迹然后退出 ------------------------------------------
func doUnlock() {
	// 1. 立旗,通知所有进程停止复活
	_ = os.MkdirAll(baseDir, 0755)
	_ = os.WriteFile(stopFile(), []byte("stop"), 0644)

	// 2. 给同伴进程一点时间看到旗子并自行退出
	time.Sleep(3 * time.Second)

	// 3. 还原注册表 / 任务栏 / 持久化 / 启动夹副本
	releaseLockdown()
	removePersistence()

	// 4. 注意:STOP 旗子故意保留。
	//    这样即便某个同伴进程此刻正在睡,醒来也一定能看到并退出。
	//    下次正常启动 Gati 时,main 会先把旗子清掉。

	msg, _ := syscall.UTF16PtrFromString("Gati 已解除\n\n" +
		"锁屏窗口、自启项、看门狗都已清理。\n" +
		"如果屏幕上还有残留窗口,注销或重启一次即可。\n\n" +
		"配置文件位置:\n" + baseDir)
	cap, _ := syscall.UTF16PtrFromString("Gati")
	pMessageBoxW.Call(0, uintptr(unsafe.Pointer(msg)), uintptr(unsafe.Pointer(cap)), 0x40)
	os.Exit(0)
}
