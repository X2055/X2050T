#!/usr/bin/env bash
# 端到端联调：起 C2 -> wine 里跑客户端 -> 下发指令 -> 验证回传
set -u
cd "$(dirname "$0")"

MASTER=$(cat build/master.key)
LOG_SRV=/tmp/c2srv.log
LOG_CLI=/tmp/gati.log
FIFO=/tmp/c2fifo

rm -f "$LOG_SRV" "$LOG_CLI" "$FIFO"
mkfifo "$FIFO"

python3 server/c2_server.py --cert keys/cert.pem --key keys/cert.key \
  --master "$MASTER" --port 8443 --console < "$FIFO" > "$LOG_SRV" 2>&1 &
SRV=$!

exec 3> "$FIFO"
sleep 3

echo "[*] 启动客户端 …"
wine build/Gati_console.exe -skipcheck > "$LOG_CLI" 2>&1 &
CLI=$!

sleep 12
echo "list" >&3
sleep 2
echo "use 1" >&3
sleep 2
echo "info" >&3
sleep 2
echo "cmd echo GATI_E2E_OK & ver" >&3

echo "[*] 等待心跳与指令执行（最多 100 秒）…"
for i in $(seq 1 20); do
  sleep 5
  if grep -q "GATI_E2E_OK" "$LOG_SRV" 2>/dev/null; then
    echo "[+] 命中回传"
    break
  fi
done

sleep 2
echo "result" >&3
sleep 3

echo "===== 服务端日志 ====="
cat "$LOG_SRV"
echo "===== 客户端日志 ====="
cat "$LOG_CLI"

kill "$CLI" 2>/dev/null
kill "$SRV" 2>/dev/null
exec 3>&-
rm -f "$FIFO"
