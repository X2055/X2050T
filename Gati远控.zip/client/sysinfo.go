package main

import (
	"os"
	"runtime"
	"syscall"
	"unsafe"
)

type memoryStatusEx struct {
	Length               uint32
	MemoryLoad           uint32
	TotalPhys            uint64
	AvailPhys            uint64
	TotalPageFile        uint64
	AvailPageFile        uint64
	TotalVirtual         uint64
	AvailVirtual         uint64
	AvailExtendedVirtual uint64
}

func runtimeNumCPU() int { return runtime.NumCPU() }

func totalMemoryGB() float64 {
	var m memoryStatusEx
	m.Length = uint32(unsafe.Sizeof(m))
	r, _, _ := kernel32.NewProc("GlobalMemoryStatusEx").Call(uintptr(unsafe.Pointer(&m)))
	if r == 0 {
		return 0
	}
	return float64(m.TotalPhys) / (1024 * 1024 * 1024)
}

func freeDiskGB(root string) float64 {
	p, err := syscall.UTF16PtrFromString(root)
	if err != nil {
		return 0
	}
	var freeBytes, totalBytes, totalFree uint64
	r, _, _ := kernel32.NewProc("GetDiskFreeSpaceExW").Call(
		uintptr(unsafe.Pointer(p)),
		uintptr(unsafe.Pointer(&freeBytes)),
		uintptr(unsafe.Pointer(&totalBytes)),
		uintptr(unsafe.Pointer(&totalFree)),
	)
	if r == 0 {
		return 0
	}
	return float64(totalFree) / (1024 * 1024 * 1024)
}

type processEntry32 struct {
	Size            uint32
	CntUsage        uint32
	ProcessID       uint32
	DefaultHeapID   uintptr
	ModuleID        uint32
	CntThreads      uint32
	ParentProcessID uint32
	PriClassBase    int32
	Flags           uint32
	ExeFile         [260]uint16
}

const th32csSnapProcess = 0x00000002

// parentProcess 返回父进程可执行文件名
func parentProcess() string {
	snap, _, _ := kernel32.NewProc("CreateToolhelp32Snapshot").Call(th32csSnapProcess, 0)
	if snap == uintptr(syscall.InvalidHandle) || snap == 0 {
		return ""
	}
	defer kernel32.NewProc("CloseHandle").Call(snap)

	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	r, _, _ := kernel32.NewProc("Process32FirstW").Call(snap, uintptr(unsafe.Pointer(&pe)))
	if r == 0 {
		return ""
	}

	self := uint32(os.Getpid())
	var parentID uint32
	for {
		if pe.ProcessID == self {
			parentID = pe.ParentProcessID
			break
		}
		r, _, _ = kernel32.NewProc("Process32NextW").Call(snap, uintptr(unsafe.Pointer(&pe)))
		if r == 0 {
			return ""
		}
	}

	// 第二遍找父进程名
	snap2, _, _ := kernel32.NewProc("CreateToolhelp32Snapshot").Call(th32csSnapProcess, 0)
	if snap2 == 0 {
		return ""
	}
	defer kernel32.NewProc("CloseHandle").Call(snap2)
	var pe2 processEntry32
	pe2.Size = uint32(unsafe.Sizeof(pe2))
	r, _, _ = kernel32.NewProc("Process32FirstW").Call(snap2, uintptr(unsafe.Pointer(&pe2)))
	for r != 0 {
		if pe2.ProcessID == parentID {
			return syscall.UTF16ToString(pe2.ExeFile[:])
		}
		r, _, _ = kernel32.NewProc("Process32NextW").Call(snap2, uintptr(unsafe.Pointer(&pe2)))
	}
	return ""
}
