module gati

go 1.22
